

<!--
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  -->
<style>
img{
  max-width:180px;
}
input[type=file]{
padding:10px;
background:#2d2d2d;}  
</style>    
  
  
  

<section class="content-header">
    <h1>
        Student
        <small><small>EntryForm</small></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-8">             
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--<h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <!-- <form role="form">-->
                
                
            <!--FOR SUCCESSFUL insert-->   
            <div id="zmsg">
                            <?php
                            
                            $msg = $this->session->userdata('message');
                            //echo "I am here";
                            //echo $msg;
                            //exit();
                            
                            if ($msg) {
                                echo '<p id="smsg" style="color:green; font-size:18px; font_weight:bold;";>' . $msg . '</p>';
                                exit();
                                $this->session->unset_userdata('message');
                            }/* else{
                              echo '<p style="color:green; font-weight:bold;">' . 'Please login with your Username and Password.' . '</p>';
                              } */
                            ?>    
            </div>    
            <!--FOR SUCCESSFUL Insert-->                 
            
            
<!--<form action="<?php echo base_url(); ?>super_admin/save_student" method="POST" enctype="multipart/form-data">-->
    <form class="form-horizontal" action="<?php echo base_url();?>super_admin/save_student" method="post" enctype="multipart/form-data">
    
    
                    <div class="box-body">
                        <div class="form-group">
                            <label for="student_name">Name<span class="req">*</span></label>
                            <input required type="text" class="form-control" name="student_name" id="student_name" placeholder="Enter Student Name">
                        </div>
                        
                        <div class="form-group">
                            <label for="student_gurdian">Gurdian</label>
                            <input type="text" class="form-control" name="student_gurdian" id="student_gurdian" placeholder="Enter Gurdian Name">
                        </div>

                        <div class="form-group">
                            <label>Date of Birth:</label>
                            <div class="input-group date" data-provide="datepicker">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" name="student_dob" id="student_dob" class="form-control pull-right" >
                            </div>
                        </div>                        
<!--//autoclose: true-->


<!--<div class="input-group date" data-provide="datepicker">
    <input type="text" class="form-control" id="datepicker">
    <div class="input-group-addon">
        <span class="glyphicon glyphicon-th"></span>
    </div>
</div>-->








                        <div class="form-group">
                            <label for="student_gender">Gender</label>
                            <select name="student_gender" id="student_gender" class="form-control">
                                <option>Select Gender</option>                      
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="student_blood_group">Blood Group</label>
                            <select name="student_blood_group" id="student_blood_group" class="form-control">
                                <option>Select Blood Group</option>                                    
                                <option>A+</option>
                                <option>A-</option>
                                <option>B+</option>
                                <option>B-</option>
                                <option>O+</option>
                                <option>O-</option>
                                <option>AB+</option>
                            </select>               
                        </div>

                        <div class="form-group">
                            <label for="student_relegion">Religion</label>
                            <select name="student_relegion" id="student_relegion" class="form-control">
                                <option>Select Religion</option>                                  
                                <option>Hinduism</option>
                                <option>Islam</option>
                                <option>Buddhism</option>
                                <option>Jainism</option>
                                <option>Christianity</option>
                                <option>Sikhism</option>
                                <option>Other</option>
                            </select>               
                        </div>

                        <div class="form-group">
                            <label for="student_email">Email</label>
                            <input type="text" class="form-control" name="student_email" id="student_email" placeholder="Enter Student Email">
                        </div>

                        <div class="form-group">
                            <label for="student_phone">Phone</label>
                            <input type="text" class="form-control" name="student_phone" id="student_phone" placeholder="Enter Phone No">
                        </div>

                        <div class="form-group">
                            <label for="student_address">Address</label>
                            <textarea class="form-control" rows="4" name="student_address" id="student_address"></textarea>                            
                        </div>

<!--                        <div class="form-group">
                            <label for="student_country">Country</label>
                            <input type="text" class="form-control" name="student_country" id="student_country" placeholder="Enter Country">
                        </div>-->


                        <div class="form-group">
                            <label for="student_country">Country</label>
                            <select name="student_country" id="student_country" class="form-control">
                                <option>Select Country</option>                                    
                                <option>India</option>
                                <option>Bangladesh</option>
                                <option>Sri Lanka</option>
                                <option>Bhutan</option>
                                <option>China</option>
                            </select>               
                        </div>

















<!--                        <div class="form-group">
                            <label for="student_state">State</label>
                            <input type="text" class="form-control" name="student_state" id="student_state" placeholder="Enter State">
                        </div>-->


                        <div class="form-group">
                            <label for="student_state">State</label>
                            <select name="student_state" id="student_state" class="form-control">
                                <option>Select State</option>                                    
                                <option>West Bengal</option>
                                <option>Bihar</option>
                                <option>Uttar Prasdesh</option>
                                <option>Karnataka</option>
                                <option>Gujarat</option>
                            </select>               
                        </div>


<!--                        <div class="form-group">
                            <label for="student_city">City</label>
                            <input type="text" class="form-control" name="student_city" id="student_city" placeholder="Enter State">
                        </div>-->

                        <div class="form-group">
                            <label for="student_city">City</label>
                            <select name="student_city" id="student_city" class="form-control">
                                <option>Select City</option>                                    
                                <option>Kolkata</option>
                                <option>Delhi</option>
                                <option>Mumbai</option>
                                <option>Patna</option>
                                <option>Lucknow</option>
                            </select>               
                        </div>


                        <div class="form-group">
                            <label for="student_class">Class<span class="req">*</span></label>
                            <select required name="student_class" id="student_class" class="form-control">
                                <option>Select Class</option>                                
                                <option>One</option>
                                <option>Two</option>
                                <option>Three</option>
                                <option>Four</option>
                                <option>Five</option>
                                <option>Six</option>
                                <option>Seven</option>
                                <option>Eight</option>
                                <option>Nine</option>
                                <option>Ten</option>
                                <option>Ex-Student</option>                              
                            </select>               
                        </div>

                        <div class="form-group">
                            <label for="student_section">Section<span class="req">*</span></label>
                            <select name="student_section" id="student_section" class="form-control required">
                                <option>Select Section</option>                                 
                                <option>A</option>
                                <option>B</option>
                                <option>C</option>
                                <option>D</option>
                            </select>               
                        </div>

                        <div class="form-group">
                            <label for="student_group">Group</label>
                            <div class="form-group">
                                <select name="student_group" id="student_group" class="form-control">
                                    <option>Select Group</option>                                     
                                    <option>Art</option>
                                    <option>Science</option>
                                    <option>Commerce</option>
                                </select>               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="student_opt_subject">Optional Subject</label>
                            <div class="form-group">
                                <select name="student_opt_subject" id="student_opt_subject" class="form-control">
                                    <option>Select Opt Subject</option>                                     
                                    <option>Hindi</option>
                                    <option>Bengali</option>
                                    <option>Math</option>
                                </select>               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="student_register_no">Register No<span class="req">*</span></label>
                            <input type="text" class="form-control" name="student_register_no" id="student_register_no" placeholder="Enter Register No.">
                        </div>

                        <div class="form-group">
                            <label for="student_roll_no">Roll<span class="req">*</span></label>
                            <input type="text" class="form-control" name="student_roll_no" id="student_roll_no" placeholder="Enter Roll No.">
                        </div>

<!--                      https://bootsnipp.com/snippets/eNbOa                     -->

<!--                        <div class="form-group">
                            <label for="student_photo">Upload Image</label>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" name="student_photo" id="student_photo" 
                                       class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>-->
                     

<!--              <div class="form-group">
                <label for="student_photo">Image Upload</label>
                <div class="controls">
                    <input type="file" class="input-file uniform_on" name="student_photo" id="student_photo">
                </div>
              </div>                         -->






<!--              <div class="form-group">
                <label for="student_photo">Image Upload</label>
                <div class="controls">
                    <input type="file" class="input-file uniform_on" name="student_photo" id="student_photo">
                </div>
              </div>  
                        <div>
                            <img src="image/student_image/avatar5.png">
                        </div>-->

<!--
    <div class="form-group">
        <label>Upload Image</label>
        <div class="input-group">
            <span class="input-group-btn">
                <span class="btn btn-default btn-file">
                    Browse… <input type="file" id="imgInp">
                </span>
            </span>
            <input type="text" class="form-control" readonly>
        </div>
        <img id='img-upload'/>
    </div>             -->
                        



  <div class="form-group">
    <label for="student_photo">Image Upload</label>
    <div class="controls">
        <input type="file" onchange="readURL(this);" class="input-file uniform_on" name="student_photo" id="student_photo">
    <!--<input type='file' onchange="readURL(this);" />-->
        <img id="blah" src="../../../image/student_image/100x100.png" alt="your image" />
        
    </div>
  </div> 

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        <div class="form-group">
                            <label for="student_extra_curr">Extra Curricular Activities</label>
                            <input type="text" class="form-control" name="student_extra_curr" id="student_extra_curr" placeholder="Enter Extra Curricular Activities">
                        </div>

                        <div class="form-group">
                            <label for="student_remark">Remarks</label>
                            <textarea class="form-control" rows="4" name="student_remark" id="student_remark"></textarea>                                                        
                        </div>

                        <div class="form-group">
                            <label for="student_username">Username<span class="req">*</span></label>
                            <input type="text" class="form-control" name="student_username" id="student_username" placeholder="Enter Extra Curricular Activities">
                        </div>

                        <div class="form-group">
                            <label for="student_password">Password<span class="req">*</span></label>
                            <input type="password" class="form-control" name="student_password" id="student_password" placeholder="Enter Extra Curricular Activities">
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>




<script>

   function readURL(input) {
       //alert("Image View Activated...");
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        
</script>
