<h3 style="margin:0 auto;height:300px; width:700px; color:green; background: yellow; border:5px solid blue; margin-bottom:25px;">
    User already exist, Please Login
</h3>