<h3 style="margin:0 auto; width:700px; color:green; background: yellow; border:2px solid blue; margin-bottom:25px;">
    Dear User, Your Account Activated Successfully, you can LOGIN now.
</h3>