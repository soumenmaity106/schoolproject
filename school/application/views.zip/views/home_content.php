<!--<h1>This is Home Content</h1>-->

<?php
//echo "I am here 1";
//exit();
?>
        
<section class="rev_slider_wrapper mt-xs-45">
    <div class="rev_slider materialize-slider">
        <ul>

            <li data-transition="fade" data-slotamount="default" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-thumb="<?php echo base_url(); ?>assets/img/seo/slider/slider-bg-1.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="materialize Material" data-description="">

                <img src="<?php echo base_url(); ?>assets/img/seo/slider/slider-bg-1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>

                <div class="tp-caption NotGeneric-Title tp-resizeme" data-x="['left','left','center','center']" data-hoffset="['20','20','0','0']" data-y="['center','center','top','top']" data-voffset="['-100','-100','50','50']" data-fontsize="['70','60','50','45']" data-lineheight="['70','60','40','40']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:600;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="800" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 5; color: #373a3d; white-space: nowrap;">Welcome to Aapka School
                </div>

                <div class="tp-caption tp-resizeme rev-subheading" data-x="['left','left','center','center']" data-hoffset="['20','20','0','0']" data-y="['center','center','top','top']" data-voffset="['0','0','140','140']" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:600;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 6; color: #666; white-space: nowrap;">materialize is an interactive agency. Which develops websites <br> and premium mobile applications.
                </div>

                <div class="tp-caption tp-resizeme" data-x="['left','left','center','center']" data-hoffset="['20','20','0','0']" data-y="['middle','middle','top','top']" data-voffset="['100','100','220','220']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-style_hover="cursor:default;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:600;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;">
                    <a href="#" class="btn btn-lg  waves-effect waves-light">Explore More</a>
                </div>

                <div class="tp-caption tp-resizeme" data-x="['right','right','center','center']" data-hoffset="['30','30','0','0']" data-y="['middle','middle','bottom','bottom']" data-voffset="['30','30','50','50']" data-transform_idle="o:1;" data-transform_in="y:30px;opacity:0;s:600;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1500;e:Power4.easeIn;" data-start="1200" style="z-index: 8;">
                    <div><img src="<?php echo base_url(); ?>assets/img/seo/slider/monitor.png" alt="">
                    </div>
                </div>

                <div class="tp-caption tp-resizeme rs-parallaxlevel-2" data-x="['right','right','center','center']" data-hoffset="['300','300','-180','-180']" data-y="['middle','middle','middle','middle']" data-voffset="['-160','-160','0','0']" data-transform_idle="o:1;" data-transform_in="y:30px;opacity:0;s:600;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1500;e:Power4.easeIn;" data-start="1500" style="z-index: 9;">
                    <div><img src="<?php echo base_url(); ?>assets/img/seo/slider/envelop.png" alt="">
                    </div>
                </div>

                <div class="tp-caption tp-resizeme rs-parallaxlevel-2" data-x="['right','right','center','center']" data-hoffset="['160','160','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-220','-220','-60','-60']" data-transform_idle="o:1;" data-transform_in="y:30px;opacity:0;s:600;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1500;e:Power4.easeIn;" data-start="1700" style="z-index: 10;">
                    <div><img src="<?php echo base_url(); ?>assets/img/seo/slider/bar.png" alt="">
                    </div>
                </div>

                <div class="tp-caption tp-resizeme rs-parallaxlevel-2" data-x="['right','right','center','center']" data-hoffset="['20','20','180','180']" data-y="['middle','middle','middle','middle']" data-voffset="['-170','-170','0','0']" data-transform_idle="o:1;" data-transform_in="y:30px;opacity:0;s:600;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1500;e:Power4.easeIn;" data-start="1900" style="z-index: 11;">
                    <div><img src="<?php echo base_url(); ?>assets/img/seo/slider/chart.png" alt="">
                    </div>
                </div>

                <div class="tp-caption tp-resizeme rs-parallaxlevel-3" data-x="['right','right','center','center']" data-hoffset="['200','200','-100','-100']" data-y="['middle','middle','bottom','bottom']" data-voffset="['80','80','30','30']" data-transform_idle="o:1;" data-transform_in="y:30px;opacity:0;s:600;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1500;e:Power4.easeIn;" data-start="2100" style="z-index: 12;">
                    <div class="rs-pendulum" data-easing="Power4.easeInOut" data-startdeg="0" data-enddeg="15"><img src="<?php echo base_url(); ?>assets/img/seo/slider/seo-mag.png" alt="">
                    </div>
                </div>
            </li>


            <li data-transition="fade" data-slotamount="default" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-thumb="<?php echo base_url(); ?>assets/img/seo/slider/slider-bg-1.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="materialize Material" data-description="">

                <img src="<?php echo base_url(); ?>assets/img/seo/slider/slider-bg-1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>

                <div class="tp-caption NotGeneric-Title tp-resizeme" data-x="['left','left','center','center']" data-hoffset="['20','20','0','0']" data-y="['center','center','top','top']" data-voffset="['-100','-100','50','50']" data-fontsize="['70','60','50','45']" data-lineheight="['70','60','40','40']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:600;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="800" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 5; color: #373a3d; white-space: nowrap;">Updation in Progress
                </div>

                <div class="tp-caption tp-resizeme rev-subheading" data-x="['left','left','center','center']" data-hoffset="['20','20','0','0']" data-y="['center','center','top','top']" data-voffset="['0','0','140','140']" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:600;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 6; color: #666; white-space: nowrap;">materialize is an interactive agency. Which develops websites <br> and premium mobile applications.
                </div>

                <div class="tp-caption tp-resizeme" data-x="['left','left','center','center']" data-hoffset="['20','20','0','0']" data-y="['middle','middle','top','top']" data-voffset="['100','100','220','220']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-style_hover="cursor:default;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:600;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;">
                    <a href="#" class="btn btn-lg  waves-effect waves-light">Explore More</a>
                </div>

                <div class="tp-caption tp-resizeme" data-basealign="slide" data-x="['right','right','center','center']" data-hoffset="['0','0','0','0']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['0','0','0','0']" data-transform_idle="o:1;" data-transform_in="y:30px;opacity:0;s:600;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1500;e:Power4.easeIn;" data-start="1500" style="z-index: 8;">
                    <div><img src="<?php echo base_url(); ?>assets/img/seo/slider/graph.png" alt="">
                    </div>
                </div>
            </li>

        </ul>
    </div>
</section>


<?php
//echo "<big>I am here 2</big>";
//exit();
?>



<section class="section-padding">
    <div class="container">
        <div class="text-center mb-80">
            <h2 class="section-title text-uppercase">What We Do</h2>
            <p class="section-sub">Quisque non erat mi. Etiam congue et augue sed tempus. Aenean sed ipsum luctus, scelerisque ipsum nec, iaculis justo. Sed at vestibulum purus, sit amet viverra diam nulla ac nisi rhoncus.</p>
        </div>
        <div class="seo-featured-carousel brand-dot">
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-1.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Web Optimize</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-2.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Data Analysis</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-3.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Concept Development</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-4.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Content Marketing</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-5.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Big Data</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-6.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Mobile Marketing</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-7.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Data Organize</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
            <div class="featured-item seo-service">
                <div class="icon">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/img/seo/service-8.jpg" alt="">
                </div>
                <div class="desc">
                    <h2>Pay Per Click</h2>
                    <p>Porttitor communicate pandemic data rather than enabled niche pandemic data rather markets</p>
                    <div class="bg-overlay"></div>
                    <p><a class="learn-more" href="#">Learn More <i class="fa fa-long-arrow-right"></i></a></p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section-padding dark-bg lighten-4">
    <div class="container">
        <div class="row">
            <div class="col-md-7 light-grey-text">
                <h2 class="font-40 mb-30 white-text">We Offer a Full Range of Digital Marketing Services!</h2>
                <p>Quisque non erat mi. Etiam congue et augue sed tempus. Aenean sed ipsum luctus, scelerisque ipsum nec, iaculis justo. Sed at vestibulum purus, sit amet viverra diam. </p>
                <ul class="list-icon mb-30">
                    <li><i class="material-icons">&#xE876;</i> We deliver Top Rankings.</li>
                    <li><i class="material-icons">&#xE876;</i> High customer retention rate.</li>
                    <li><i class="material-icons">&#xE876;</i> We always return e-mails and calls within one business day.</li>
                </ul>
                <a href="#." class="btn btn-lg text-capitalize waves-effect waves-light">Contact Us</a>
            </div>
            <div class="col-md-5 mt-sm-30">
                <img src="<?php echo base_url(); ?>assets/img/seo/seo-info-light.png" alt="" class="img-responsive">
            </div>
        </div>
    </div>
</section>
<section class="section-padding">
    <div class="container">
        <div class="text-center mb-80">
            <h2 class="section-title text-uppercase">Why Choose Us</h2>
            <p class="section-sub">Quisque non erat mi. Etiam congue et augue sed tempus. Aenean sed ipsum luctus, scelerisque ipsum nec, iaculis justo. Sed at vestibulum purus, sit amet viverra diam nulla ac nisi rhoncus.</p>
        </div>
        <div class="row">
            <div class="col-md-4 mb-50">
                <div class="featured-item feature-icon icon-hover icon-hover-brand icon-outline">
                    <div class="icon">
                        <i class="material-icons colored brand-icon">&#xE02F;</i>
                    </div>
                    <div class="desc">
                        <h2>Content</h2>
                        <p>Porttitor communicate pandemic data rather than enabled niche markets neque pulvinar vitae.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-50">
                <div class="featured-item feature-icon icon-hover icon-hover-brand icon-outline">
                    <div class="icon">
                        <i class="material-icons colored brand-icon">&#xE01D;</i>
                    </div>
                    <div class="desc">
                        <h2>Strategy</h2>
                        <p>Porttitor communicate pandemic data rather than enabled niche markets neque pulvinar vitae.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-50">
                <div class="featured-item feature-icon icon-hover icon-hover-brand icon-outline">
                    <div class="icon">
                        <i class="material-icons colored brand-icon">&#xE80D;</i>
                    </div>
                    <div class="desc">
                        <h2>Social Media</h2>
                        <p>Porttitor communicate pandemic data rather than enabled niche markets neque pulvinar vitae.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-50">
                <div class="featured-item feature-icon icon-hover icon-hover-brand icon-outline">
                    <div class="icon">
                        <i class="material-icons colored brand-icon">&#xE869;</i>
                    </div>
                    <div class="desc">
                        <h2>Optimize</h2>
                        <p>Porttitor communicate pandemic data rather than enabled niche markets neque pulvinar vitae.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-50">
                <div class="featured-item feature-icon icon-hover icon-hover-brand icon-outline">
                    <div class="icon">
                        <i class="material-icons colored brand-icon">&#xE8FA;</i>
                    </div>
                    <div class="desc">
                        <h2>Keyword Research</h2>
                        <p>Porttitor communicate pandemic data rather than enabled niche markets neque pulvinar vitae.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-50">
                <div class="featured-item feature-icon icon-hover icon-hover-brand icon-outline">
                    <div class="icon">
                        <i class="material-icons colored brand-icon">&#xE7FD;</i>
                    </div>
                    <div class="desc">
                        <h2>Trafic</h2>
                        <p>Porttitor communicate pandemic data rather than enabled niche markets neque pulvinar vitae.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="promo-box gray-bg border-box mt-100">
            <div class="promo-info">
                <h2 class="text-extrabold text-uppercase font-25">Get awesome marketing services</h2>
                <p>Asunt in anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.</p>
            </div>
            <div class="promo-btn">
                <a href="#." class="btn btn-lg text-capitalize waves-effect waves-light">Get it now</a>
            </div>
        </div>
    </div>
</section>
<section class="section-padding gray-bg">
    <div class="container">
        <div class="text-center mb-50">
            <h2 class="section-title text-uppercase">Case Studies</h2>
            <p class="section-sub">Quisque non erat mi. Etiam congue et augue sed tempus. Aenean sed ipsum luctus, scelerisque ipsum nec, iaculis justo. Sed at vestibulum purus, sit amet viverra diam nulla ac nisi rhoncus.</p>
        </div>
        <div class="portfolio-container text-center">
            <ul class="portfolio-filter brand-filter">
                <li class="active waves-effect waves-light" data-group="all">All</li>
                <li class="waves-effect waves-light" data-group="websites">Websites</li>
                <li class="waves-effect waves-light" data-group="branding">Branding</li>
                <li class="waves-effect waves-light" data-group="marketing">Marketing</li>
                <li class="waves-effect waves-light" data-group="analysis">Analysis</li>
            </ul>
            <div class="portfolio col-4 mtb-50">

                <div class="portfolio-item" data-groups='["all", "branding", "analysis"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-1.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a href="#"> <i class="fa fa-link"></i> </a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Branding</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="portfolio-item" data-groups='["all", "marketing", "websites"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-2.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a href="#"> <i class="fa fa-link"></i> </a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Marketing</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="portfolio-item" data-groups='["all", "analysis", "branding"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-3.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a href="#"> <i class="fa fa-link"></i> </a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Strategy</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="portfolio-item" data-groups='["all", "websites", "branding"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-4.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a class="popup-video" href="https://www.youtube.com/watch?v=XVfOe5mFbAE"> <i class="fa fa-play"></i> </a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Video</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="portfolio-item" data-groups='["all", "analysis", "marketing"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-5.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a href="#"> <i class="fa fa-link"></i> </a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Branding</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="portfolio-item" data-groups='["all", "websites",  "marketing"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-6.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a href="#"> <i class="fa fa-link"></i></a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Marketing</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="portfolio-item" data-groups='["all", "websites", "analysis"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-7.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a href="#"> <i class="fa fa-link"></i> </a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Branding</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="portfolio-item" data-groups='["all", "branding", "marketing"]'>
                    <div class="portfolio-wrapper">
                        <div class="thumb">
                            <div class="bg-overlay"></div>
                            <img src="<?php echo base_url(); ?>assets/img/seo/portfolio/portfolio-8.jpg" alt="">
                            <div class="portfolio-intro">
                                <div class="action-btn">
                                    <a href="#"> <i class="fa fa-link"></i> </a>
                                </div>
                                <h2><a href="#">Portfolio Title</a></h2>
                                <p><a href="#">Branding</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="padding-top-110 padding-bottom-70 brand-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="quote-carousel text-center">
                    <div class="carousel-item">
                        <div class="content">
                            <h2 class="white-text line-height-40">"My favorite things in life don't cost any money. It's really clear that the most precious resource we all have is time."</h2>
                            <div class="testimonial-meta font-20 text-extrabold white-text">
                                Steve Jobes
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="content">
                            <h2 class="white-text line-height-40">"My favorite things in life don't cost any money. It's really clear that the most precious resource we all have is time."</h2>
                            <div class="testimonial-meta font-20 text-extrabold white-text">
                                Steve Jobes
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="content">
                            <h2 class="white-text line-height-40">"My favorite things in life don't cost any money. It's really clear that the most precious resource we all have is time."</h2>
                            <div class="testimonial-meta font-20 text-extrabold white-text">
                                Steve Jobes
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section-padding">
    <div class="container">
        <div class="text-center mb-80">
            <h2 class="section-title text-uppercase">Awesome clients</h2>
            <p class="section-sub">Quisque non erat mi. Etiam congue et augue sed tempus. Aenean sed ipsum luctus, scelerisque ipsum nec, iaculis justo. Sed at vestibulum purus, sit amet viverra diam. Nulla ac nisi rhoncus,</p>
        </div>
        <div class="clients-grid gutter">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="border-box">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>assets/img/client-logo/1.png" alt="clients">
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="border-box">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>assets/img/client-logo/2.png" alt="clients">
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="border-box">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>assets/img/client-logo/4.png" alt="clients">
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="border-box">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>assets/img/client-logo/5.png" alt="clients">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section-padding gray-bg">
    <div class="container">
        <div class="text-center mb-80">
            <h2 class="section-title text-uppercase">Pricing table</h2>
            <p class="section-sub">Quisque non erat mi. Etiam congue et augue sed tempus. Aenean sed ipsum luctus, scelerisque ipsum nec, iaculis justo. Sed at vestibulum purus, sit amet viverra diam nulla ac nisi rhoncus.</p>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="pricing-table">
                    <div class="table-contents text-center">
                        <div class="table-header brand-hover">
                            <div class="package-name">
                                <span>Basic</span>
                            </div>
                            <div class="package-price">
                                <span class="currency-symbol">$</span>
                                <span class="price">59</span>
                                <span class="currency-code">/Day</span>
                            </div>
                        </div> 
                        <div class="table-info">
                            <ul>
                                <li>Keyword</li>
                                <li>Time Tracking</li>
                                <li>Man Hour</li>
                                <li><del>Workshop</del></li>
                                <li><del>Certificate</del></li>
                            </ul>
                        </div>
                        <div class="table-footer">
                            <div class="purchase-button">
                                <a class="btn btn-lg text-capitalize waves-effect waves-light" href="#">Buy Now</a>
                            </div>
                        </div> 
                    </div> 
                </div>
            </div>
            <div class="col-md-4">
                <div class="pricing-table">
                    <div class="table-contents text-center">
                        <div class="table-header brand-hover">
                            <div class="package-name">
                                <span>Standard</span>
                            </div>
                            <div class="package-price">
                                <span class="currency-symbol">$</span>
                                <span class="price">79</span>
                                <span class="currency-code">/Day</span>
                            </div>
                        </div> 
                        <div class="table-info">
                            <ul>
                                <li>Front Seats</li>
                                <li>Free Snacks</li>
                                <li>Printed T-Shirt</li>
                                <li>Workshop</li>
                                <li><del>Certificate</del></li>
                            </ul>
                        </div>
                        <div class="table-footer">
                            <div class="purchase-button">
                                <a class="btn btn-lg text-capitalize waves-effect waves-light" href="#">Buy Now</a>
                            </div>
                        </div> 
                    </div> 
                </div>
            </div>
            <div class="col-md-4">
                <div class="pricing-table">
                    <div class="table-contents text-center">
                        <div class="table-header brand-hover">
                            <div class="package-name">
                                <span>Premium</span>
                            </div>
                            <div class="package-price">
                                <span class="currency-symbol">$</span>
                                <span class="price">99</span>
                                <span class="currency-code">/Day</span>
                            </div>
                        </div> 
                        <div class="table-info">
                            <ul>
                                <li>Front Seats</li>
                                <li>Free Snacks</li>
                                <li>Printed T-Shirt</li>
                                <li>Workshop</li>
                                <li>Certificate</li>
                            </ul>
                        </div>
                        <div class="table-footer">
                            <div class="purchase-button">
                                <a class="btn btn-lg text-capitalize waves-effect waves-light" href="#">Buy Now</a>
                            </div>
                        </div> 
                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section-padding featured-list-news">
    <div class="container">
        <div class="text-center mb-80">
            <h2 class="section-title text-uppercase">Latest Blog</h2>
            <p class="section-sub">Quisque non erat mi. Etiam congue et augue sed tempus. Aenean sed ipsum luctus, scelerisque ipsum nec, iaculis justo. Sed at vestibulum purus, sit amet viverra diam nulla ac nisi rhoncus.</p>
        </div>
        <div class="row">
            <div class="col-md-6">
                <article class="post-wrapper featured-news">
                    <div class="thumb-wrapper waves-effect waves-block waves-light">
                        <a href="#"><img src="<?php echo base_url(); ?>assets/img/blog/blog-12.jpg" class="img-responsive" alt=""></a>
                    </div>
                    <div class="blog-content">
                        <header class="entry-header-wrapper">
                            <div class="entry-header">
                                <h2 class="entry-title"><a href="#">My Most Memorable Moment as a Product Designer</a></h2>
                                <div class="entry-meta">
                                    <ul class="list-inline">
                                        <li>
                                            By <a href="#">Trendy Theme</a>
                                        </li>
                                        <li>
                                            In <a href="#">Technology</a>
                                        </li>
                                        <li>
                                            At <a href="#">Jan 15, 2016</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </header>
                        <div class="entry-content">
                            <p>Maecenas varius finibus orci vel dignissim. Nam posuere, magna pellentesque accumsan tincidunt, libero lorem.</p>
                            <a href="#" class="readmore">Read Full Post <i class="fa fa-long-arrow-right"></i></a>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-md-6">
                <article class="post-wrapper list-article">
                    <div class="hover-overlay brand-bg"></div>
                    <div class="thumb-wrapper waves-effect waves-block waves-light">
                        <a href="#"><img src="<?php echo base_url(); ?>assets/img/blog/blog-22.jpg" class="img-responsive" alt=""></a>
                    </div>
                    <div class="blog-content">
                        <header class="entry-header-wrapper">
                            <div class="entry-header">
                                <h2 class="entry-title"><a href="#">Ideas That Moved Us in 2015</a></h2>
                                <div class="entry-meta">
                                    <ul class="list-inline">
                                        <li>
                                            By <a href="#">Admin</a>
                                        </li>
                                        <li>
                                            In <a href="#">Technology</a>
                                        </li>
                                        <li>
                                            At <a href="#">Jan 15, 2016</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </header>
                        <div class="entry-content">
                            <p>Maecenas varius finibus orci vel dignissim. Nam posuere, magna pellentesque accumsan.</p>
                            <a href="#" class="readmore">Read Full Post <i class="fa fa-long-arrow-right"></i></a>
                        </div>
                    </div>
                </article>
                <article class="post-wrapper list-article">
                    <div class="hover-overlay brand-bg"></div>
                    <div class="thumb-wrapper waves-effect waves-block waves-light">
                        <a href="#"><img src="<?php echo base_url(); ?>assets/img/blog/blog-23.jpg" class="img-responsive" alt=""></a>
                    </div>
                    <div class="blog-content">
                        <header class="entry-header-wrapper">
                            <div class="entry-header">
                                <h2 class="entry-title"><a href="#">Ideas That Moved Us in 2015</a></h2>
                                <div class="entry-meta">
                                    <ul class="list-inline">
                                        <li>
                                            By <a href="#">Admin</a>
                                        </li>
                                        <li>
                                            In <a href="#">Technology</a>
                                        </li>
                                        <li>
                                            At <a href="#">Jan 15, 2016</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </header>
                        <div class="entry-content">
                            <p>Maecenas varius finibus orci vel dignissim. Nam posuere, magna pellentesque accumsan</p>
                            <a href="#" class="readmore">Read Full Post <i class="fa fa-long-arrow-right"></i></a>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section>
