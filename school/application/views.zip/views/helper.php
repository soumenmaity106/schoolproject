<?php

//$connect = mysqli_connect("localhost", "root", "", "test_db");  
//$sql="update tbl_order set serial_no = substr(item_name,1,1) where substr(item_name,2,1)='.'";
//mysqli_query($connect, $sql); 

//                $sql = "INSERT INTO tbl_order(item_name, qty, price) VALUES ('".$item_name."', '".$qty."', '".$price."')";  
//                $sql = "INSERT INTO tbl_order(item_name) VALUES ('".$item_name."')";  
//                mysqli_query($connect, $sql);  
    
