<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Super_Admin_Model extends CI_Model {
    
public function save_category_info($data)
{
    $this->db->INSERT('tbl_category',$data);
}


public function save_student_info($data)
{
    $this->db->INSERT('tbl_student',$data);
}




//save_parent_info
public function save_parent_info($data)
{
    $this->db->INSERT('tbl_parent',$data);
}

//save_teacher_info
public function save_teacher_info($data)
{
    $this->db->INSERT('tbl_teacher',$data);
}


//save_teacher_info
public function save_user_info($data)
{
    $this->db->INSERT('tbl_user',$data);
}


public function save_class_info($data)
{
    $this->db->INSERT('tbl_class',$data);
}



public function save_subject_info($data)
{
    $this->db->INSERT('tbl_subject',$data);
}


//save_section_info
public function save_section_info($data)
{
    $this->db->INSERT('tbl_section',$data);
}


//save_syllabus_info
public function save_syllabus_info($data)
{
    $this->db->INSERT('tbl_syllabus',$data);
}


//save_assignment
public function save_syllabus_info($data)
{
    $this->db->INSERT('tbl_syllabus',$data);
}




























public function select_all_student()
{
    $this->db->select('*');
    $this->db->FROM(' tbl_student');
    $query_result = $this->db->get();
    $result = $query_result->result();
    return $result;        
}


public function select_all_category()
{
    $this->db->select('*');
    $this->db->FROM('tbl_category');
    $query_result = $this->db->get();
    $result = $query_result->result();
    return $result;        
}
   
public function select_category_info_by_id($category_id)
{
    $this->db->select('*');
    $this->db->FROM('tbl_category');
    $this->db->WHERE('category_id', $category_id);
    $query_result = $this->db->get();
    $result = $query_result->row();
    return $result;        
}

public function update_unpublished_category_by_id($category_id)
{
    $this->db->set('publication_status',0);
    $this->db->WHERE('category_id', $category_id);
    $this->db->UPDATE('tbl_category');
}        

public function update_published_category_by_id($category_id)
{
    $this->db->set('publication_status',1);
    $this->db->WHERE('category_id', $category_id);
    $this->db->UPDATE('tbl_category');
}        

public function delete_category_info($category_id)
{
    $this->db->WHERE('category_id', $category_id);
    $this->db->DELETE('tbl_category');
}

public function update_category_info($data, $category_id)
{
    $this->db->WHERE('category_id', $category_id);
    $this->db->UPDATE('tbl_category',$data);        
}















     public function get_cats()
     {
          return $this->db->get("cats");
     }

     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
   public function save_blog_info($data)
   {
     $this->db->INSERT('tbl_blog',$data);
   }
   
    public function select_all_blog()
    {
        $this->db->select('*');
        $this->db->FROM('tbl_blog');
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;        
        
    }
   
         

    
}
