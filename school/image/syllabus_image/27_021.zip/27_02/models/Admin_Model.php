<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Admin_Model extends CI_Model {
    
    public function admin_login_check_info($admin_email_address,$admin_password)
    {
      $this->db->select('*');
      $this->db->from('tbl_admin');
      $this->db->where('admin_email_address', $admin_email_address);
      $this->db->where('admin_password', md5($admin_password));
      
      $query_result = $this->db->get();  //This is Resource Location
      $result = $query_result->row();    //Selecting Single Record from the Resource Location.
      
      /*echo "<pre>";
      echo "Value in result is : ";
      print_r($result);
      var_dump($result);
      exit();*/
     
      return $result; 
    }



    
    
}
