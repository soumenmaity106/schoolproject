<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

error_reporting(0);
//session_start();
//if(!isset($_SESSION)){
//    session_start();
//}
class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $admin_id = $this->session->userdata('admin_id');
        //echo "I am here................<br>";
//        if($admin_id != NULL)
//          {
//           //echo "There is nothng in the session"; 
//           //exit();
//           //redirect('Super_admin','refresh');
//          }
    }

    public function index()
    {
     $this->load->view('admin/login');    
    }
    
    
    
    public function admin_login_check()
    {
     ////$this->load->view('admin/admin_master');    
     //$admin_email_address = $_POST['admin_email_address']; //php procedural way   
     $admin_email_address = $this->input->post('admin_email_address', TRUE);
     $admin_password      = $this->input->post('admin_password', TRUE);
     //$submit_case         = $this->input->post('submit', TRUE);
     
     //echo $admin_email_address."<br>";
     //echo $admin_password."<br>";
     //exit();
     //echo "i am here<br>";
     $this->load->model('Admin_Model','a_model');  // name_of_model, object_of_that_model
     $result = $this->a_model->admin_login_check_info($admin_email_address,$admin_password);  // sending param
     
     /*echo "<pre>";
     ///echo "submit_case is :" . $submit_case->submit;  
     print_r($result);
     var_dump($result);
     exit();*/
     
     $ses_data = array(); //Declaring Session Array
        if($result)
          {
            //echo "inside result<br>";
           $ses_data['admin_name'] = $result->admin_name;  
           $ses_data['admin_id']   = $result->admin_id;  
           
           //echo $ses_data['admin_name']."<br>";
           //echo $ses_data['admin_id']."<br>";
           //exit();
           
           //echo $ses_data['admin_id'];
           //echo "<br>";
           //echo $ses_data['admin_full_name'];
           //exit();
           
           $this->session->set_userdata($ses_data);
           //echo "<h1>Session hold following values</h1>";
           //echo "<h3>" . $this->session->userdata('admin_id') . "</h3>";
           //echo "<h3>" . $this->session->userdata('admin_name') . "</h3>";
           //exit();
           
           //echo "I am here";
           //exit();
           redirect('Super_admin');
          }  
        else
          {
           //echo "<h1>Password is Incorrect</h1>";
           //exit();
           $ses_data['exception'] = 'Your Userid or Password Invalid !!!!'; 
           $this->session->set_userdata($ses_data);
           //echo "I am hera due to wrong password................"."<br>";
           //redirect('admin/index'); 
           redirect('admin'); 
           //$this->index();       //all 3 will redirec to same controller
          }  
    }
    
    
    
    
    
    
    
    
    
//    
//    
//    
//    public function category_management()
//    {
//     //$this->load->view('admin/category');   
//     $data = array();
//     $data['ADMINMAINCONTENT'] = $this->load->view('admin/category','',TRUE);
//     $this->load->view('admin/ADMIN_MASTER',$data);   
//     
//    }
//    
//
//    public function blog_management()
//    {
//     //$this->load->view('admin/category');   
//     $data = array();
//     $data['ADMINMAINCONTENT'] = $this->load->view('admin/blog','',TRUE);
//     $this->load->view('admin/ADMIN_MASTER',$data);   
//     
//    }
    
    
    
    
    
    
    
    
    
}
