<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//if(!isset($_SESSION)){
//    session_start();
//}++
error_reporting(0);
session_start();

class Super_admin extends CI_Controller {
    
    public function __construct() 
    {
        parent::__construct();
        $admin_id = $this->session->userdata('admin_id');
        //$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
        //echo "I am here................<br>";
        //echo $admin_id;
        //exit();
        if($admin_id == NULL)
          {
           //echo "There is nothng in the session"; 
           //exit();
           //redirect('admin','refresh');
          }
          //$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
          //$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
    }
    
    
    public function index()
    {
        $data = array();
        $data['ADMINMAINCONTENT'] = $this->load->view('admin/dashboard', $data, TRUE);
        $this->load->view('admin/ADMIN_MASTER', $data);   
        //$this->load->view('admin/admin_master'); 
    } 
    
    

    public function logout()
    {
       echo "<br>"; 
       echo "I am in Logout function<br>";
       echo "Before unset<br>";
       echo $this->session->userdata('admin_id');
       echo "<br>";
       echo $this->session->userdata('admin_full_name');
       echo "<br>";
       /////////////////////////exit();
       
       $this->session->unset_userdata('admin_id');
       $this->session->unset_userdata('admin_full_name');
       
       /*echo "After unset<br>";
       echo $this->session->userdata('admin_id');
       echo "<br>";
       echo $this->session->userdata('admin_full_name');
       echo "<br>";
       exit();*/
       
       $sdata=array();
       $sdata['message'] = 'You are <big>s</big>uccessfully logged out...'; 
       $this->session->set_userdata($sdata);
       redirect('admin');
    }
            

    
    
    
    
    public function xadd_student()
    {
      echo "<h1>I am here</h1>";
      exit();
      $data = array();
      //$this->load->model('Welcome_model','Wel_model');
      //$data['all_published_category'] = $this->Wel_model->select_all_published_category();
      //echo "<pre>";
      //print_r($data);
      //exit();
      //$data['ADMINMAINCONTENT'] = $this->load->view('admin/add_blog_form', $data, TRUE);
      //$this->load->view('admin/ADMIN_MASTER', $data);   
      $this->load->view('admin/add_student_form');   
    }
    
    
    //CATEGORY    
    public function add_student()
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_student_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    
    public function save_student()
    {
         $data = array();   
         $data['student_name']          = $this->input->post('student_name',TRUE);
         $data['student_gurdian']       = $this->input->post('student_gurdian',TRUE);
         $data['student_dob']           = $this->input->post('student_dob',TRUE);        
         $data['student_gender']        = $this->input->post('student_gender',TRUE);                 
         $data['student_blood_group']   = $this->input->post('student_blood_group',TRUE);        
         $data['student_relegion']      = $this->input->post('student_relegion',TRUE);        
         $data['student_email']         = $this->input->post('student_email',TRUE);                 
         $data['student_phone']         = $this->input->post('student_phone',TRUE);        
         $data['student_address']       = $this->input->post('student_address',TRUE);        
         $data['student_country']       = $this->input->post('student_country',TRUE);                 
         $data['student_state']         = $this->input->post('student_state',TRUE);        
         $data['student_city']          = $this->input->post('student_city',TRUE);        
         $data['student_class']         = $this->input->post('student_class',TRUE);                 
         $data['student_section']       = $this->input->post('student_section',TRUE);        
         $data['student_group']         = $this->input->post('student_group',TRUE);   
         //$data['student_roll']          = $this->input->post('student_roll',TRUE);   
         $data['student_opt_subject']   = $this->input->post('student_opt_subject',TRUE);                 
         $data['student_register_no']   = $this->input->post('student_register_no',TRUE);        
         $data['student_roll_no']       = $this->input->post('student_roll_no',TRUE);        
         $data['student_photo']         = $this->input->post('student_photo',TRUE);                 
         $data['student_extra_curr']    = $this->input->post('student_extra_curr',TRUE);        
         $data['student_remark']        = $this->input->post('student_remark',TRUE);        
         $data['student_username']      = $this->input->post('student_username',TRUE);                 
         $data['student_password']      = $this->input->post('student_password',TRUE);     
         


                        //echo '<pre>';
                        //print_r($_POST);
                        //echo '<pre>';
                        //print_r($_FILES);
                        
                        //exit();
        
        /*
         * =====================Start Image upload
         */
		$config['upload_path'] = 'image/student_image/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_size']	= '100';  // kilobyte
		$config['max_width']  = '1024';
		$config['max_height']  = '768';

                //load liabrary then initialize
		$this->load->library('upload', $config);
                $this->upload->initialize($config);
                
                $error='';
                $fdata = array();
		if ( ! $this->upload->do_upload('student_photo'))
		{
			//$error = array('error' => $this->upload->display_errors());
                        $error = $this->upload->display_errors();
                        echo $error;
                        //exit();
			//$this->load->view('upload_form', $error);
		}
		else
		{
			//$fdata = array('upload_data' => $this->upload->data());
                        $fdata = $this->upload->data();
                        $data['student_photo']=$config['upload_path'].$fdata['file_name'];
                        
                        //echo '<pre>';
                        //print_r($fdata);
                        //exit();

			//$this->load->view('upload_success', $data);
		}
        
        
        /*
         * =====================End Image upload
         */
         
         
         
         
//         echo $data['student_name']."<br>";
//         echo $data['student_gurdian']."<br>";
//         echo $data['student_dob']."<br>";        
//         echo $data['student_gender']."<br>";                 
//         echo $data['student_blood_group']."<br>";        
//         echo $data['student_relegion']."<br>";        
//         echo $data['student_email']."<br>";                 
//         echo $data['student_phone']."<br>";        
//         echo $data['student_address']."<br>";        
//         echo $data['student_country']."<br>";                 
//         echo $data['student_state']."<br>";        
//         echo $data['student_city']."<br>";        
//         echo $data['student_class']."<br>";                 
//         echo $data['student_section']."<br>";        
//         echo $data['student_group']."<br>";        
//         echo $data['student_opt_subject']."<br>";                 
//         echo $data['student_register_no']."<br>";        
//         echo $data['student_roll_no']."<br>";        
//         echo $data['student_photo']."<br>";                 
//         echo $data['student_extra_curr']."<br>";        
//         echo $data['student_remark']."<br>";        
//         echo $data['student_username']."<br>";                 
//         echo $data['student_password']."<br>";     
//         exit();
         
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_student_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_student');
        }

        
        
        
        
        
        
        
    public function manage_student()
    {
      $data = array();
      $data['all_student'] = $this->sa_model->select_all_student();                //both published and unpublished 
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/manage_student_form',$data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);     
    }

        
        
        
        
        
        
        
        
        
        
        
        
        
    





    
    
    
    
    
    
    
    
    public function save_parent()
    {
         //echo "I am here";
        
         $data = array();   
         $data['parent_name']              = $this->input->post('parent_name',TRUE);
         $data['parent_father_name']       = $this->input->post('parent_father_name',TRUE);
         $data['parent_mother_Name']       = $this->input->post('parent_mother_Name',TRUE);
         $data['parent_father_profession'] = $this->input->post('parent_father_profession',TRUE);
         $data['parent_mother_profession'] = $this->input->post('parent_mother_profession',TRUE);
         $data['parent_email']             = $this->input->post('parent_email',TRUE);
         $data['parent_phone']             = $this->input->post('parent_phone',TRUE);
         $data['parent_address']           = $this->input->post('parent_address',TRUE);
         $data['parent_photo']             = $this->input->post('parent_photo',TRUE);
         $data['parent_username']          = $this->input->post('parent_username',TRUE);
         $data['parent_password']          = $this->input->post('parent_password',TRUE);

         /*echo $data['parent_name']."<br>";
         echo $data['parent_father_name']."<br>";
         echo $data['parent_mother_Name']."<br>";
         echo $data['parent_father_profession']."<br>";
         echo $data['parent_mother_profession']."<br>";
         echo $data['parent_email']."<br>";
         echo $data['parent_phone']."<br>";
         echo $data['parent_address']."<br>";
         echo $data['parent_photo']."<br>";
         echo $data['parent_username']."<br>";
         echo $data['parent_password']."<br>";*/
         //exit();
        
         //exit();
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_parent_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_parent');
        }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    














    


    public function add_teacher()
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_teacher_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    
    
    
    
        public function save_teacher()
    {
         //echo "I am here";
        
         $data = array();   
         $data['teacher_name']        = $this->input->post('teacher_name',TRUE);
         $data['teacher_designation'] = $this->input->post('teacher_designation',TRUE);
         $data['teacher_DOB']         = $this->input->post('teacher_DOB',TRUE);
         $data['teacher_gender']      = $this->input->post('teacher_gender',TRUE);
         $data['teacher_religion']    = $this->input->post('teacher_religion',TRUE);
         $data['teacher_email']       = $this->input->post('teacher_email',TRUE);
         $data['teacher_phone']       = $this->input->post('teacher_phone',TRUE);
         $data['teacher_address']     = $this->input->post('teacher_address',TRUE);
         $data['teacher_DOJ']         = $this->input->post('teacher_DOJ',TRUE);
         $data['teacher_photo']       = $this->input->post('teacher_photo',TRUE);
         $data['teacher_username']    = $this->input->post('teacher_username',TRUE);
         $data['teacher_password']    = $this->input->post('teacher_password',TRUE);

         echo $data['teacher_name']."<br>";
         echo $data['teacher_designation']."<br>";
         echo $data['teacher_DOB']."<br>";
         echo $data['teacher_gender']."<br>";
         echo $data['teacher_religion']."<br>";
         echo $data['teacher_email']."<br>";
         echo $data['teacher_phone']."<br>";
         echo $data['teacher_address']."<br>";
         echo $data['teacher_DOJ']."<br>";
         echo $data['teacher_photo']."<br>";
         echo $data['teacher_username']."<br>";
         echo $data['teacher_password']."<br>";
         
         //exit();
        
         //exit();
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_teacher_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_teacher');
        }


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public function add_parent()
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_parent_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }

















    
    


    public function add_user()
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_user_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    

    
    
    
    
        public function save_user()
    {
         //echo "I am here";
        
         $data = array();   
         $data['user_name']     = $this->input->post('user_name',TRUE);
         $data['user_role']     = $this->input->post('user_role',TRUE);
         $data['user_DOB']      = $this->input->post('user_DOB',TRUE);
         $data['user_gender']   = $this->input->post('user_gender',TRUE);
         $data['user_religion'] = $this->input->post('user_religion',TRUE);
         $data['user_email']    = $this->input->post('user_email',TRUE);
         $data['user_phone']    = $this->input->post('user_phone',TRUE);
         $data['user_address']  = $this->input->post('user_address',TRUE);
         $data['user_DOJ']      = $this->input->post('user_DOJ',TRUE);
         $data['user_photo']    = $this->input->post('user_photo',TRUE);
         $data['user_username'] = $this->input->post('user_username',TRUE);
         $data['user_password'] = $this->input->post('user_password',TRUE);

         echo $data['user_name']."<br>";
         echo $data['user_role']."<br>";
         echo $data['user_DOB']."<br>";
         echo $data['user_gender']."<br>";
         echo $data['user_religion']."<br>";
         echo $data['user_email']."<br>";
         echo $data['user_phone']."<br>";
         echo $data['user_address']."<br>";
         echo $data['user_DOJ']."<br>";
         echo $data['user_photo']."<br>";
         echo $data['user_username']."<br>";
         echo $data['user_password']."<br>";
         
         //exit();
        
         //exit();
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_user_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_user');
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    //save_class
        public function save_class()
    {
         //echo "I am here";
        
         $data = array();   
         $data['student_class']      = $this->input->post('student_class',TRUE);
         $data['class_numeric']      = $this->input->post('class_numeric',TRUE);
         $data['class_teacher_name'] = $this->input->post('class_teacher_name',TRUE);
         $data['class_note']         = $this->input->post('class_note',TRUE);

         echo $data['student_class']."<br>";
         echo $data['class_numeric']."<br>";
         echo $data['class_teacher_name']."<br>";
         echo $data['class_note']."<br>";
         
         //exit();
        
         //exit();
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_class_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_class');
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    public function add_class()  //Standard
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_class_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    

    public function add_subject()  //Standard
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_subject_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    
    
        //save_class
        public function save_subject()
    {
         //echo "I am here";
         //exit();
         $data = array();   
         $data['class_name']     = $this->input->post('class_name',TRUE);
         $data['teacher_name']   = $this->input->post('teacher_name',TRUE);
         $data['subject_type']   = $this->input->post('subject_type',TRUE);
         $data['pass_mark']      = $this->input->post('pass_mark',TRUE);
         $data['final_mark']     = $this->input->post('final_mark',TRUE);
         $data['subject_name']   = $this->input->post('subject_name',TRUE);
         $data['subject_author'] = $this->input->post('subject_author',TRUE);
         $data['subject_code']   = $this->input->post('subject_code',TRUE);

         echo $data['class_name']."<br>";
         echo $data['teacher_name']."<br>";
         echo $data['subject_type']."<br>";
         echo $data['pass_mark']."<br>";
         echo $data['final_mark']."<br>";
         echo $data['subject_name']."<br>";
         echo $data['subject_author']."<br>";
         echo $data['subject_code']."<br>";
         
         //exit();
        
         //exit();
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_subject_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_class');
        }
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    public function add_section()  //Standard
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_section_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    
    
    
        public function save_section()
    {
         //echo "I am here";
         //exit();
         $data = array();   
         $data['section_name']         = $this->input->post('section_name',TRUE);
         $data['section_category']     = $this->input->post('section_category',TRUE);
         $data['section_capacity']     = $this->input->post('section_capacity',TRUE);
         $data['section_class']        = $this->input->post('section_class',TRUE);
         $data['section_teacher_name'] = $this->input->post('section_teacher_name',TRUE);
         $data['section_note']         = $this->input->post('section_note',TRUE);

         echo $data['section_name']."<br>";
         echo $data['section_category']."<br>";
         echo $data['section_capacity']."<br>";
         echo $data['section_class']."<br>";
         echo $data['section_teacher_name']."<br>";
         echo $data['section_note']."<br>";
         
         //exit();
        
         //exit();
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_section_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_section');
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public function add_syllabus()  //Standard
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_syllabus_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }


    
    
    
    
    
        public function save_syllabus()
    {
         //echo "I am here";
         //exit();
         $data = array();   
         $data['syllabus_title']       = $this->input->post('syllabus_title',TRUE);
         $data['syllabus_description'] = $this->input->post('syllabus_description',TRUE);
         $data['syllabus_class']       = $this->input->post('syllabus_class',TRUE);
         $data['syllabus_file']        = "lo"; //$this->input->post('syllabus_file',TRUE);

         echo $data['syllabus_title']."<br>";
         echo $data['syllabus_description']."<br>";
         echo $data['syllabus_class']."<br>";
         echo $data['syllabus_file']."<br>";
         
         //exit();
        
         //exit();
         //############################################
         //instead of loading in each function better it to define in constructon so that all function get it
         ////$this->load->model('Super_Admin_Model','sa_model');  // name_of_model, object_of_that_model
         //############################################
         
         //$this->sa_model->save_category_info($data);
         $this->sa_model->save_syllabus_info($data);
         
         $sdata = array();
         $sdata['message'] = 'Data Inserted Successfully into Database !!!!'; 
         $this->session->set_userdata($sdata);
         redirect('super_admin/add_section');
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    public function add_assignment()  //Standard
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_assignment_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    
    
    public function add_routine()  //Standard
    {
      //echo "I am inside the add_student function";
      //exit();
      $data = array();
      $data['ADMINMAINCONTENT'] = $this->load->view('admin/add_routine_form', $data, TRUE);
      $this->load->view('admin/ADMIN_MASTER', $data);   
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
