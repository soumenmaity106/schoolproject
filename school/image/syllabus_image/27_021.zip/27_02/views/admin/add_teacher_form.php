<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>







<!-- Date Picker 
  <link rel="stylesheet" href="<?php // echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

 datepicker 
<script src="<?php // echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<script>
    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })
 </script> 
-->


<section class="content-header">
    <h1>
        Teacher
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
<!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
<!--                <form role="form">-->
<form id="form1" action="<?php echo base_url(); ?>super_admin/save_teacher" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">                                        
                    <div class="box-body">
                        <div class="form-group">
                            <label for="teacher_name">Name</label>
                            <input type="text" class="form-control" name="teacher_name" id="teacher_name" placeholder="Enter Teacher Name">
                        </div>
                        
                        
                        
                        <div class="form-group">
                            <label for="teacher_designation">Designation</label>
                            <input type="text" class="form-control" name="teacher_designation" id="teacher_designation" placeholder="Enter Designation">
                        </div>
                        

                        
                        <div class="form-group">
                            <label for="teacher_DOB">Date of Birth</label>
                            <input type="text" class="form-control" name="teacher_DOB" id="teacher_DOB" placeholder="Enter Date of Birth">
                        </div>
                        

                        
<!--                        <div class="form-group">
                            <label for="teacher_gender">Gender</label>
                            <select class="form-control">
                              <option>Male</option>
                              <option>Female</option>
                            </select>
                        </div>-->
                        <div class="form-group">
                            <label for="teacher_gender">Gender</label>
                            <select name="teacher_gender" id="teacher_gender" class="form-control">
                                <option>Select Gender</option>                      
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                        </div>
                        
                        
                        
                        
<!--                        <div class="form-group">
                            <label for="teacher_religion">Religion</label>
                            <input type="text" class="form-control" name="teacher_religion" id="teacher_religion" placeholder="Enter Relegion">
                        </div>-->

                        <div class="form-group">
                            <label for="teacher_religion">Religion</label>
                            <select name="teacher_religion" id="teacher_religion" class="form-control">
                                <option>Select Religion</option>                                  
                                <option>Hinduism</option>
                                <option>Islam</option>
                                <option>Buddhism</option>
                                <option>Jainism</option>
                                <option>Christianity</option>
                                <option>Sikhism</option>
                                <option>Other</option>
                            </select>               
                        </div>

                        
                        
                        
                        <div class="form-group">
                            <label for="teacher_email">Email</label>
                            <input type="text" class="form-control" name="teacher_email" id="teacher_email" placeholder="Enter Teacher Email">
                        </div>
                        


                        <div class="form-group">
                            <label for="teacher_phone">Phone</label>
                            <input type="text" class="form-control" name="teacher_phone" id="teacher_phone" placeholder="Enter Phone No">
                        </div>
                        
                        
                        
                        <div class="form-group">
                            <label for="teacher_address">Address</label>
                            <textarea class="form-control" rows="4" name="teacher_address" id="teacher_address" placeholder="Enter Address"></textarea>                            
                        </div>
                        
                        

                        <div class="form-group">
                            <label for="teacher_DOJ">Joining Date</label>
                            <input type="text" class="form-control" name="teacher_DOJ" id="teacher_DOJ" placeholder="Joining Date">
                        </div>
                        
                        
                        
                        <!--https://bootsnipp.com/snippets/eNbOa -->                    
                        <div class="form-group">
                            <label for="teacher_photo">Upload Image</label>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" name="teacher_photo" id="teacher_photo" class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>                        
                        
                        
                        
                        <div class="form-group">
                            <label for="teacher_username">Username</label>
                            <input type="text" class="form-control" name="teacher_username" id="teacher_username" placeholder="Enter Extra Curricular Activities">
                        </div>

                        
                        
                        <div class="form-group">
                            <label for="teacher_password">Password</label>
                            <input type="password" class="form-control" name="teacher_password" id="teacher_password" placeholder="Enter Extra Curricular Activities">
                        </div>
                        
                        
                        
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->




        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>
  
  
  
  
  



<script>

<!-- IMAGE UPLOAD START    
    $(document).ready(function () {
        $(document).on('change', '.btn-file :file', function () {
            var input = $(this),
                    label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
            input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function (event, label) {

            var input = $(this).parents('.input-group').find(':text'),
                    log = label;

            if (input.length) {
                input.val(log);
            } else {
                if (log)
                    alert(log);
            }

        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function () {
            readURL(this);
        });
    });
            <!-- IMAGE UPLOAD END        
            
</script>
