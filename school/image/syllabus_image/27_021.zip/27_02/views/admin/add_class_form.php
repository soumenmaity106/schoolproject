
<!-- Date Picker 
  <link rel="stylesheet" href="<?php // echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

 datepicker 
<script src="<?php // echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<script>
    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })
 </script> 
-->


<section class="content-header">
    <h1>
        Class (Standard)
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
<!--                <form role="form">-->
                <form id="form1" action="<?php echo base_url(); ?>super_admin/save_class" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">                                        
                    <div class="box-body">
<!--                        <div class="form-group">
                            <label for="class">Class</label>
                            <input type="text" class="form-control" name="class" id="class" placeholder="Enter Class (in word)">
                        </div>-->
                        <div class="form-group">
                            <label for="student_class">Class<span class="req">*</span></label>
                            <select required name="student_class" id="student_class" class="form-control">
                                <option>Select Class</option>                                
                                <option>One</option>
                                <option>Two</option>
                                <option>Three</option>
                                <option>Four</option>
                                <option>Five</option>
                                <option>Six</option>
                                <option>Seven</option>
                                <option>Eight</option>
                                <option>Nine</option>
                                <option>Ten</option>
                                <option>Ex-Student</option>                              
                            </select>               
                        </div>
                        



                        <div class="form-group">
                            <label for="class_numeric">Class_Numeric</label>
                            <input type="text" class="form-control" name="class_numeric" id="class_numeric" placeholder="Enter Class (in number)">
                        </div>

                        
                        
                        <div class="form-group">
                            <label for="class_teacher_name">Teacher Name</label>
                            <select name="class_teacher_name" id="class_teacher_name" class="form-control">
                                <option>Select Teacher</option>                      
                                <option>Teacher1</option>
                                <option>Teacher2</option>
                            </select>
                        </div>



                        
                        <div class="form-group">
                            <label for="class_note">Note</label>
                            <textarea class="form-control" rows="4" name="class_note" id="class_note" placeholder="Enter Class Note"></textarea>                            
                        </div>




                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>








