<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css"/>

<script src="jquery-1.12.4.js" type="text/javascript"></script>
<script src="jquery.dataTables.min.js" type="text/javascript"></script>

        
<script>
$(document).ready(function() {
    $('#student-table').DataTable();
} );      
</script>        
        








<!--<script src="https://code.jquery.com/jquery-1.12.4.js" type="text/javascript"></script>-->
<!--<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>-->





<script type="text/javascript">
//$(document).ready(function() {
//    $('#student-table').DataTable();
} );






//    $(document).ready(function () {
//        $('#student-table').DataTable(
//                {
//                  "bResetDisplay": false,                    
//                    "pageLength":2,
//                    "lengthMenu": [
//                        [2, 5, 10, 15, 25, 50, -1],
//                        [2, 5, 10, 15, 25, 50, "All"]
//                    ],
//                     /*"iDisplayLength":5,*/
//                     /*"ajax": "data.json",*/
//                     "sPaginationType": "full_numbers",
//                     "bStateSave": true,     
//                     "drawCallback": function( settings ) {
//      /*alert ( 'You are on ssame page' );*/
//}
//                });
//
//        //$('#cat-table').DataTable.draw('full-hold');
//        //$('#cat-table').DataTable.draw(false);
//        //$('#myTable').DataTable.draw('full-hold');
//        //oTable.fnDraw();
//        
//        
//        
//        /*[code]
//        function Button2_onclick() {
//        var iCurrentPage = oTable.fnSettings()._iDisplayStart;
//        var oSettings = oTable.fnSettings();
//        oSettings._iDisplayStart = iCurrentPage;
//        oTable.fnDraw(oSettings);
//        }
//        [/code]*/        
//
//
//        /*
//         WRONG SHOULD BE CSS NOT ATTR
//         $('#cat-table tr td').attr('padding','0');
//         $('#cat-table tr td').attr('margin','0');
//         $('#cat-table tr td').attr('min-height','3px');              
//         $('#cat-table tr td').attr('height','4px');   
//         */
//
///*$('#td1').css('width','104px');
//$('#td2').css('width','104px');
//$('#td3').css('width','104px');
//$('#td4').css('width','104px');
//$('#td5').css('width','104px');*/
//
//        //$('#cat-table tr td')  .css('padding-top','0');
//        //$('#cat-table tr td')  .css('padding-bottom','0');
//        //$('#cat-table tr td')  .css('margin','0');
//        //$('#cat-table tr td')  .css('min-height','8px');              
//        //$('#cat-table tr td')  .css('height','8px');   
//        //$('#cat-table tr td p').css('height','8px');         // THE VALUD INSIDE TR->TD HAS TO BE SAME AS THE HEIGHT   
//        $('#cat-table tr td p').css('font-size', '13px');      // THE FONT SIZE INSIDE THE CELL
//        $('#cat-table tr td').css('font-size', '12px');        // THE FONT SIZE INSIDE THE CELL
//        $('#cat-table tr td').css('font-family','cursive');    // THE FONT SIZE INSIDE THE CELL
//        $('#cat-table tr td p').css('font-family','cursive');  // THE FONT SIZE INSIDE THE CELL
//        //
//        //
//        /*$('#cat-table tr td').hover(function () {
//            $(this).css('font-size', '17px');
//            $(this).css('font-weight', 'bold');
//            //$(this).css('background', '#272727');
//            //$(this).css('color', '#FFFFFF');
//        }, function () {
//            $(this).css('font-size', '12px');
//            $(this).css('font-weight', 'normal');
//            //$(this).css('background', '#FFFFFF');
//            //$(this).css('color', '#000000');
//        });*/
//////////////////////////////////////////////////////////////////////////////////
//        /*$('#cat-table tr td p').hover(function () {
//            $(this).css('font-size', '17px');
//            $(this).css('font-weight', 'bold');
//            //$(this).css('background', '#272727');
//            //$(this).css('color', '#FFFFFF');
//        }, function () {
//            $(this).css('font-size', '13px');
//            $(this).css('font-weight', 'normal');
//            //$(this).css('background', '#FFFFFF');
//            //$(this).css('color', '#000000');
//        });*/
//
//        /*  $('#cat-table tr td').hover(function(){
//         $(this).css('height','25px');
//         //$(this).css('font-weight','bold');    
//         }, function(){
//         $(this).css('height','8px');
//         //$(this).css('font-weight','normal');  
//         });*/
//
//
//
//
//    });
//
//



</script>






    




<hr>
<table id="student-table" class="table table-striped table-bordered table-hover table-responsive">
    <thead>
        <tr>
    <center>
        <th width="10%">StudentID</th>
        <th width="20%">Photo</th>
        <th width="30%">Name</th>
        <th width="10%">Roll</th>
        <th width="10%">Email</th>
        <th width="20%">Action</th>        
    </center>            
</tr>
</thead>

<tbody>
    <?php
    foreach ($all_student as $v_all_student) {
        ?>        
        <tr>
            <!--<div style="height:15px; min-height:15px; overflow :auto;">-->
    <div>             
        <td id="td1"><?php echo $v_all_student->student_id; ?></td>
        <td id="td2"><?php echo $v_all_student->student_photo; ?></td>
        
       <!-- <a id="popover" data-trigger="hover"> -->
        <td id="td3"><?php echo substr($v_all_student->student_name, 0, 50);?></td>
       <!-- </a> -->
       
       <td id="td3"><?php echo substr($v_all_student->student_roll_no, 0, 50);?></td>
       <td id="td3"><?php echo substr($v_all_student->student_email, 0, 50);?></td>
        
<!--        
<a id="popover" data-trigger="hover">Popover</a>        
-->        
        
<!--        <td id="td4">
            <?php
            if ($v_all_student->publication_status == 1) {
                echo "Published";
            } else {
                echo "Un-published";
            }
            ?>    
        </td>-->
        
        
        
        
        
        <td id="td5">
            <?php
            if ($v_all_student->publication_status == 1) {
                ?>    
                <a class="btn btn-xs btn-success" href="<?php// echo base_url(); ?>super_Admin/unpublished_student/<?php echo $v_all_student->student_id; ?>" title="Published">
                    <span class="glyphicon glyphicon-arrow-up">
                    </span>
                </a>
                <?php
            } else {
                ?>    
                <a class="btn btn-xs btn-danger" href="<?php// echo base_url(); ?>super_Admin/published_student/<?php echo $v_all_student->student_id; ?>" title="Published">
                    <span class="glyphicon glyphicon-arrow-down">
                    </span>
                </a>
                <?php
            }
            ?>
            <a class="btn btn-xs btn-default" href="<?php// echo base_url(); ?>super_Admin/edit_student/<?php echo $v_all_student->student_id; ?>" title="Edit">
                <span class="glyphicon glyphicon-pencil">
                </span>
            </a>
            <a class="btn btn-xs btn-default"  href="<?php// echo base_url(); ?>super_Admin/delete_student/<?php echo $v_all_student->student_id; ?>" title="Delete" onclick="return checkDelete();">
                <span class="glyphicon glyphicon-remove">
                </span>
            </a>
        </td>
        
        
        
        
        
        
    </div>                      
    </tr>
    <?php
}
?>        
</tbody>

</table>
























