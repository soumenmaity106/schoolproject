<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>







<!-- Date Picker 
  <link rel="stylesheet" href="<?php // echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

 datepicker 
<script src="<?php // echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<script>
    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })
 </script> 
-->


<section class="content-header">
    <h1>
        Parent
        <small><small>EntryForm</small></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
<!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
<!--                <form role="form">-->
                <form id="form1" action="<?php echo base_url(); ?>super_admin/save_parent" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">                                        
                    <div class="box-body">
                        <div class="form-group">
                            <label for="parent_name">Gurdian Name</label>
                            <input type="text" class="form-control" name="parent_name" id="parent_name" placeholder="Enter Gurdian Name">
                        </div>
                        

                        
                        <div class="form-group">
                            <label for="parent_father_name">Father Name</label>
                            <input type="text" class="form-control" name="parent_father_name" id="parent_father_name" placeholder="Enter Father Name">
                        </div>

                        
                        
                        <div class="form-group">
                            <label for="parent_mother_Name">Mother Name</label>
                            <input type="text" class="form-control" name="parent_mother_Name" id="parent_mother_Name" placeholder="Enter Mother Name">
                        </div>


                        
                        <div class="form-group">
                            <label for="parent_father_profession">Father's Profession </label>
                            <input type="text" class="form-control" name="parent_father_profession" id="parent_father_profession" placeholder="Father's Profession">
                        </div>

                        
                        
                        <div class="form-group">
                            <label for="parent_mother_profession">Mother's Profession </label>
                            <input type="text" class="form-control" name="parent_mother_profession" id="parent_mother_profession" placeholder="Mother's Profession">
                        </div>

                        
                        
                        <div class="form-group">
                            <label for="parent_email">Email</label>
                            <input type="text" class="form-control" name="parent_email" id="parent_email" placeholder="Enter Parent Email">
                        </div>
                        


                        <div class="form-group">
                            <label for="parent_phone">Phone</label>
                            <input type="text" class="form-control" name="parent_phone" id="parent_phone" placeholder="Enter Phone No">
                        </div>
                        
                        
                        
                        <div class="form-group">
                            <label for="parent_address">Address</label>
                            <textarea class="form-control" rows="4" name="parent_address" id="parent_address" placeholder="Enter Address"></textarea>                            
                        </div>

                        
                        
<!--                        <div class="form-group">
                             <label for="parent_photo">Upload Image</label>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>               -->
                        <!--https://bootsnipp.com/snippets/eNbOa -->                    
                        <div class="form-group">
                            <label for="parent_photo">Upload Image</label>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" name="parent_photo" id="parent_photo" class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>                        
                        
                        
                        
                        
                        <div class="form-group">
                            <label for="parent_username">Username</label>
                            <input type="text" class="form-control" name="parent_username" id="parent_username" placeholder="Enter Extra Curricular Activities">
                        </div>

                        
                        
                        <div class="form-group">
                            <label for="parent_password">Password</label>
                            <input type="parent_password" class="form-control" name="parent_password" id="gurdian_password" placeholder="Enter Extra Curricular Activities">
                        </div>
                        
                        
                        
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>
  
  
  
  
  



<script>

<!-- IMAGE UPLOAD START    
    $(document).ready(function () {
        $(document).on('change', '.btn-file :file', function () {
            var input = $(this),
                    label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
            input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function (event, label) {

            var input = $(this).parents('.input-group').find(':text'),
                    log = label;

            if (input.length) {
                input.val(log);
            } else {
                if (log)
                    alert(log);
            }

        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function () {
            readURL(this);
        });
    });
            <!-- IMAGE UPLOAD END        
            
</script>
