

<section class="content-header">
    <h1>
        Syllabus
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>



<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
<!--                <form role="form">-->
<form class="form-horizontal" action="<?php echo base_url();?>super_admin/save_syllabus" method="post" enctype="multipart/form-data">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="syllabus_title">Syllabus Title</label>
                            <input type="text" class="form-control" name="syllabus_title" id="syllabus_title" placeholder="Enter Syllabus Title">
                        </div>


                        
                        <div class="form-group">
                            <label for="syllabus_description">Syllabus Description</label>
                            <textarea class="form-control" rows="4" name="syllabus_description" id="syllabus_description"></textarea>                            
                        </div>


                        
                        <div class="form-group">
                            <label for="syllabus_class">Class<span class="req">*</span></label>
                            <select required name="syllabus_class" id="syllabus_class" class="form-control">
                                <option>Select Class</option>                                
                                <option>One</option>
                                <option>Two</option>
                                <option>Three</option>
                                <option>Four</option>
                                <option>Five</option>
                                <option>Six</option>
                                <option>Seven</option>
                                <option>Eight</option>
                                <option>Nine</option>
                                <option>Ten</option>
                                <option>Ex-Student</option>                              
                            </select>               
                        </div>



<!--                        <div class="form-group">
                            <label>Upload Image</label>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>                        -->



              <div class="form-group">
                <label for="syllabus_file">Image Upload</label>
                <div class="controls">
                    <input type="file" class="input-file uniform_on" name="syllabus_file" id="syllabus_file">
                </div>
              </div>                         



                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>





