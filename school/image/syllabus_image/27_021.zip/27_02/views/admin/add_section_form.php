

<section class="content-header">
    <h1>
        Section
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
<!--                <form role="form">-->
<form id="form1" action="<?php echo base_url(); ?>super_admin/save_section" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">                                        
                    <div class="box-body">
                        <div class="form-group">
                            <label for="section_name">Section Name</label>
                            <input type="text" class="form-control" name="section_name" id="section_name" placeholder="Enter Section Name">
                        </div>



                        <div class="form-group">
                            <label for="section_category">Section Category</label>
                            <input type="text" class="form-control" name="section_category" id="section_category" placeholder="Enter Section Category">
                        </div>



                        <div class="form-group">
                            <label for="section_capacity">Section Capacity</label>
                            <input type="text" class="form-control" name="section_capacity" id="section_capacity" placeholder="Enter Section Capacity">
                        </div>

                        
                        <div class="form-group">
                            <label for="section_class">Class</label>
                            <select required name="section_class" id="section_class" class="form-control">
                                <option>One</option>
                                <option>Two</option>
                                <option>Three</option>
                                <option>Four</option>
                                <option>Five</option>
                                <option>Six</option>
                                <option>Seven</option>
                                <option>Eight</option>
                                <option>Nine</option>
                                <option>Ten</option>
                                <option>Ex-Section</option>                              
                            </select>               
                        </div>
                        
                        
                        


                        <div class="form-group">
                            <label for="section_teacher_name">Teacher Name</label>
                            <select required name="section_teacher_name" id="section_teacher_name" class="form-control">
                                <option>ramOne</option>
                                <option>shyam Two</option>
                                <option>Jadu Three</option>
                                <option>Madhu Four</option>
                            </select>               
                        </div>



                        <div class="form-group">
                            <label for="section_note">Note</label>
                            <textarea class="form-control" rows="4" name="section_note" id="section_note"></textarea>                            
                        </div>




                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>





