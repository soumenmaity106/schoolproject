

<section class="content-header">
    <h1>
        Subject
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
<!--                <form role="form">-->
<form id="form1" action="<?php echo base_url(); ?>super_admin/save_subject" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">                                        
                    <div class="box-body">
<!--                        <div class="form-group">
                            <label for="Class_Name">Class Name</label>
                            <input type="text" class="form-control" name="Class_Name" id="Class_Name" placeholder="Enter Class Name">
                        </div>-->
                        <div class="form-group">
                            <label for="class_name">Class<span class="req">*</span></label>
                            <select required name="class_name" id="class_name" class="form-control">
                                <option>Select Class</option>                                
                                <option>One</option>
                                <option>Two</option>
                                <option>Three</option>
                                <option>Four</option>
                                <option>Five</option>
                                <option>Six</option>
                                <option>Seven</option>
                                <option>Eight</option>
                                <option>Nine</option>
                                <option>Ten</option>
                                <option>Ex-Student</option>                              
                            </select>               
                        </div>
                        



<!--                        <div class="form-group">
                            <label for="teacher_name">Teacher Name</label>
                            <input type="text" class="form-control" name="teacher_name" id="teacher_name" placeholder="Enter Gurdian Name">
                        </div>-->

                        <div class="form-group">
                            <label for="teacher_name">Teacher Name</label>
                            <select name="teacher_name" id="teacher_name" class="form-control">
                                <option>Select Teacher</option>                      
                                <option>Teacher1</option>
                                <option>Teacher2</option>
                            </select>
                        </div>





                        <div class="form-group">
                            <label for="subject_type">Type</label>
                            <select name="subject_type" id="subject_type" class="form-control">
                                <option>Optional</option>
                                <option>Mandatory</option>
                            </select>
                        </div>



                        <div class="form-group">
                            <label for="pass_mark">Pass Mark</label>
                            <input type="text" class="form-control" name="pass_mark" id="pass_mark" placeholder="Enter Pass Mark">
                        </div>


                        
                        <div class="form-group">
                            <label for="final_mark">Final Mark</label>
                            <input type="text" class="form-control" name="final_mark" id="final_mark" placeholder="Enter Final Mark">
                        </div>

                        

                        <div class="form-group">
                            <label for="subject_name">Subject Name</label>
                            <input type="text" class="form-control" name="subject_name" id="subject_name" placeholder="Enter Subject Name">
                        </div>

                        

                        <div class="form-group">
                            <label for="subject_author">Subject Author</label>
                            <input type="text" class="form-control" name="subject_author" id="subject_author" placeholder="Enter Subject Author">
                        </div>

                        

                        <div class="form-group">
                            <label for="subject_code">Subject Code</label>
                            <input type="text" class="form-control" name="subject_code" id="subject_code" placeholder="Enter Subject Code">
                        </div>




                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>






