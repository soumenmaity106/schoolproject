<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>




<!-- Date Picker 
  <link rel="stylesheet" href="<?php // echo base_url();  ?>assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

 datepicker 
<script src="<?php // echo base_url();  ?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<script>
    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })
 </script> 
-->


<section class="content-header">
    <h1>
        User
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
<!--                <form role="form">-->
<form id="form1" action="<?php echo base_url(); ?>super_admin/save_user" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">                                        
                    <div class="box-body">
                        <div class="form-group">
                            <label for="user_name">User_name</label>
                            <input type="text" class="form-control" name="user_name" id="user_name" placeholder="Enter User Name">
                        </div>



                        <div class="form-group">
                            <label for="user_DOB">Date of Birth</label>
                            <input type="text" class="form-control" name="user_DOB" id="user_DOB" placeholder="Enter Date of Birth">
                        </div>



<!--                        <div class="form-group">
                            <label for="user_gender">Gender</label>
                            <select class="form-control">
                                <option value="M">Male</option>
                                <option value="F">Female</option>
                            </select>
                        </div>-->
                        <div class="form-group">
                            <label for="user_gender">Gender</label>
                            <select name="user_gender" id="user_gender" class="form-control">
                                <option>Select Gender</option>                      
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                        </div>
                        



<!--                        <div class="form-group">
                            <label for="User_Relegion">Relegion</label>
                            <input type="text" class="form-control" name="User_Relegion" id="User_Relegion" placeholder="Enter Relegion">
                        </div>-->


                        <div class="form-group">
                            <label for="user_religion">Religion</label>
                            <select name="user_religion" id="user_religion" class="form-control">
                                <option>Select Religion</option>                                  
                                <option>Hinduism</option>
                                <option>Islam</option>
                                <option>Buddhism</option>
                                <option>Jainism</option>
                                <option>Christianity</option>
                                <option>Sikhism</option>
                                <option>Other</option>
                            </select>               
                        </div>




                        <div class="form-group">
                            <label for="user_email">Email</label>
                            <input type="text" class="form-control" name="user_email" id="user_email" placeholder="Enter User Email">
                        </div>



                        <div class="form-group">
                            <label for="user_phone">Phone</label>
                            <input type="text" class="form-control" name="user_phone" id="user_phone" placeholder="Enter Phone No">
                        </div>



                        <div class="form-group">
                            <label for="user_address">Address</label>
                            <textarea class="form-control" rows="4" name="user_address" id="user_address"></textarea>                            
                        </div>



                        <div class="form-group">
                            <label for="user_DOJ">Date of Joining</label>
                            <input type="text" class="form-control" name="user_DOJ" id="user_DOJ" placeholder="Enter Date of Joining">
                        </div>


                        <!--https://bootsnipp.com/snippets/eNbOa -->                    
                        <div class="form-group">
                            <label for="user_photo">Upload Image</label>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" name="user_photo" id="user_photo" class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>                        

                        
                        
                        <div class="form-group">
                            <label for="user_role">Role</label>
                            <select name="user_role" id="user_role" class="form-control">
                                <option>Select Role</option>                      
                                <option value="1">Admin</option>
                                <option value="2">Teacher</option>
                                <option value="3">Student</option>
                                <option value="4">Parent</option>
                                <option value="5">Accountant</option>
                                <option value="6">Librarian</option>
                                <option value="7">Receptionist</option>                                
                            </select>
                        </div>

                        

                        <div class="form-group">
                            <label for="user_username">Username</label>
                            <input type="text" class="form-control" name="user_username" id="user_username" placeholder="Enter Username">
                        </div>



                        <div class="form-group">
                            <label for="user_password">Password</label>
                            <input type="password" class="form-control" name="user_password" id="user_password" placeholder="Enter Password">
                        </div>



                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>








<script>

<!-- IMAGE UPLOAD START    
    $(document).ready(function () {
        $(document).on('change', '.btn-file :file', function () {
            var input = $(this),
                    label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
            input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function (event, label) {

            var input = $(this).parents('.input-group').find(':text'),
                    log = label;

            if (input.length) {
                input.val(log);
            } else {
                if (log)
                    alert(log);
            }

        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function () {
            readURL(this);
        });
    });
            <!-- IMAGE UPLOAD END        
            
</script>
