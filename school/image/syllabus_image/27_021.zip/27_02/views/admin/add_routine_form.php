




<section class="content-header">
    <h1>
        Routine
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form role="form">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="routine_school_year">School Year</label>
                            <input type="text" class="form-control" name="routine_school_year" id="routine_school_year" placeholder="Enter School Year">
                        </div>



                        <div class="form-group">
                            <label for="routine_class">Class</label>
                            <input type="text" class="form-control" name="routine_class" id="routine_class" placeholder="Enter Deadline">
                        </div>

                        <div class="form-group">
                            <label for="	routine_section">Section</label>
                            <input type="text" class="form-control" name="	routine_section" id="	routine_section" placeholder="Enter Deadline">
                        </div>





                        <div class="form-group">
                            <label for="routine_subject">Subject</label>
                            <select class="form-control">
                                <option>one1</option>
                                <option>two2</option>
                            </select>
                        </div>


                        <div class="form-group">
                            <label for="routine_day">Subject</label>
                            <select class="form-control">
                                <option>Sunday</option>
                                <option>Monday</option>
                            </select>
                        </div>                        


                        <div class="form-group">
                            <label for="routine_teacher">Subject</label>
                            <select class="form-control">
                                <option>eacherSunday</option>
                                <option>teacherMonday</option>
                            </select>
                        </div>                        

                        <div class="form-group">
                            <label for="routine_start_time">Starting Time</label>
                            <input type="text" class="form-control" name="routine_start_time" id="routine_start_time" placeholder="Enter Section">
                        </div>

                        <div class="form-group">
                            <label for="routine_end_time">Ending Time</label>
                            <input type="text" class="form-control" name="routine_end_time" id="routine_end_time" placeholder="Enter Section">
                        </div>


                        <div class="form-group">
                            <label for="	routine_room">Room</label>
                            <input type="text" class="form-control" name="	routine_room" id="	routine_room" placeholder="Enter Section">
                        </div>



                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>








