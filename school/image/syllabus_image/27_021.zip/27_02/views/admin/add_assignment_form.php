




<section class="content-header">
    <h1>
        Assignment
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <!-- left column -->
        <!--        <div class="col-md-8 col-md-offset-2">-->
        <div class="col-md-10 col-md-offset-1">              
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--                    <h3 class="box-title">Quick Example</h3>-->
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form role="form">
<!--    <form class="form-horizontal" action="<?php echo base_url();?>super_admin/save_assignment" method="post" enctype="multipart/form-data">-->
                    <div class="box-body">
                        <div class="form-group">
                            <label for="assignment_title">Title</label>
                            <input type="text" class="form-control" name="assignment_title" id="assignment_title" placeholder="Enter Title">
                        </div>



                        <div class="form-group">
                            <label for="assignment_description">Description</label>
                             <div class="form-group">
                               <textarea class="form-control" rows="4" name="assignment_section" id="assignment_section" placeholder="Enter Description"></textarea>                            
                        </div>                            
                        </div>


                        <div class="form-group">
                            <label for="assignment_deadline">Deadline</label>
                            <input type="text" class="form-control" name="assignment_deadline" id="assignment_deadline" placeholder="Enter Deadline">
                        </div>


                        <div class="form-group">
                            <label for="assignment_class">Class</label>
                            <select class="form-control">
                                <option>one1</option>
                                <option>two2</option>
                            </select>
                        </div>



                        <div class="form-group">
                            <label for="assignment_section">Section</label>
                            <input type="text" class="form-control" name="assignment_section" id="assignment_section" placeholder="Enter Section">
                        </div>

                        <div class="form-group">
                            <label for="assignment_subject">Select Subject</label>
                            <select class="form-control">
                                <option>hindi</option>
                                <option>bengali</option>
                            </select>
                        </div>



<!--                        <div class="form-group">
                            <label>Upload File</label>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>                        -->
              <div class="form-group">
                <label for="student_photo">Image Upload</label>
                <div class="controls">
                    <input type="file" class="input-file uniform_on" name="student_photo" id="student_photo">
                </div>
            </div>                         





                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->







        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">


        </div>
        <!--/.col (right) -->
    </div>
    <!-- /.row -->
</section>








