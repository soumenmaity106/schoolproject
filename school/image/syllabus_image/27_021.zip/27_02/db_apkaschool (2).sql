-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2018 at 03:01 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_apkaschool`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email_address` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email_address`, `admin_password`) VALUES
(1, 'Arjun Prasad Yadav', 'apysan@gmail.com', 'edf1009903090813acdf58478797a61f');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assignment`
--

CREATE TABLE `tbl_assignment` (
  `assignment_id` int(11) NOT NULL,
  `assignment_title` varchar(100) NOT NULL,
  `assignment_description` text NOT NULL,
  `assignment_deadline` varchar(20) NOT NULL,
  `assignment_class` varchar(100) NOT NULL,
  `assignment_section` varchar(10) NOT NULL,
  `assignment_subject` varchar(50) NOT NULL,
  `assignment_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE `tbl_city` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(50) NOT NULL,
  `city_code` varchar(5) NOT NULL,
  `dummy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_class`
--

CREATE TABLE `tbl_class` (
  `class_id` int(11) NOT NULL,
  `student_class` varchar(10) NOT NULL,
  `class_numeric` int(10) NOT NULL,
  `class_teacher_name` varchar(100) NOT NULL,
  `class_note` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_class`
--

INSERT INTO `tbl_class` (`class_id`, `student_class`, `class_numeric`, `class_teacher_name`, `class_note`) VALUES
(1, 'Two', 2, 'Teacher2', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE `tbl_country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(50) NOT NULL,
  `country_code` varchar(5) NOT NULL,
  `dummy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam`
--

CREATE TABLE `tbl_exam` (
  `exam_id` int(11) NOT NULL,
  `exam_name` varchar(50) NOT NULL,
  `exam_date` varchar(50) NOT NULL,
  `exam_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam_grade`
--

CREATE TABLE `tbl_exam_grade` (
  `exam_id` int(11) NOT NULL,
  `exam_grade_name` varchar(50) NOT NULL,
  `exam_grade_point` varchar(50) NOT NULL,
  `exam_mark_from` int(50) NOT NULL,
  `exam_mark_upto` int(50) NOT NULL,
  `exam_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam_schedule`
--

CREATE TABLE `tbl_exam_schedule` (
  `exam_id` int(11) NOT NULL,
  `exam_name` varchar(50) NOT NULL,
  `exam_date` varchar(50) NOT NULL,
  `exam_note` text NOT NULL,
  `exam_class` varchar(50) NOT NULL,
  `exam_section` varchar(50) NOT NULL,
  `exam_subject` varchar(50) NOT NULL,
  `exam_time_from` varchar(20) NOT NULL,
  `exam_time_to` varchar(20) NOT NULL,
  `exam_room` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gurdian`
--

CREATE TABLE `tbl_gurdian` (
  `Gurdian_id` int(11) NOT NULL,
  `Gurdian_name` varchar(50) NOT NULL,
  `Father_name` varchar(100) NOT NULL,
  `Mother_Name` varchar(100) NOT NULL,
  `Father_Profession` varchar(50) NOT NULL,
  `Mother_Profession` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Address` text NOT NULL,
  `Photo` varchar(100) NOT NULL,
  `gurdian_username` varchar(50) NOT NULL,
  `gurdian_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hostel`
--

CREATE TABLE `tbl_hostel` (
  `hostel_id` int(11) NOT NULL,
  `hostel_name` int(11) NOT NULL,
  `hostel_address` text NOT NULL,
  `hostel_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hostel_cat`
--

CREATE TABLE `tbl_hostel_cat` (
  `hostel_id` int(11) NOT NULL,
  `hostel_name` int(11) NOT NULL,
  `hostel_class_type` varchar(10) NOT NULL,
  `hostel_fees` text NOT NULL,
  `hostel_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_library_book`
--

CREATE TABLE `tbl_library_book` (
  `lib_book_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `author` varchar(100) NOT NULL,
  `subject_code` int(5) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `qty` decimal(12,0) NOT NULL,
  `rack_no` int(5) NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_library_memb`
--

CREATE TABLE `tbl_library_memb` (
  `lib_mem_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `roll` int(5) NOT NULL,
  `email` varchar(100) NOT NULL,
  `photo` text NOT NULL,
  `dummy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mail_sms`
--

CREATE TABLE `tbl_mail_sms` (
  `id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL,
  `users` varchar(50) NOT NULL,
  `template` text NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_parent`
--

CREATE TABLE `tbl_parent` (
  `parent_id` int(11) NOT NULL,
  `parent_name` varchar(50) NOT NULL,
  `parent_father_name` varchar(100) NOT NULL,
  `parent_mother_Name` varchar(100) NOT NULL,
  `parent_father_profession` varchar(50) NOT NULL,
  `parent_mother_profession` varchar(50) NOT NULL,
  `parent_email` varchar(100) NOT NULL,
  `parent_phone` varchar(100) NOT NULL,
  `parent_address` text NOT NULL,
  `parent_photo` varchar(100) NOT NULL,
  `parent_username` varchar(50) NOT NULL,
  `parent_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_parent`
--

INSERT INTO `tbl_parent` (`parent_id`, `parent_name`, `parent_father_name`, `parent_mother_Name`, `parent_father_profession`, `parent_mother_profession`, `parent_email`, `parent_phone`, `parent_address`, `parent_photo`, `parent_username`, `parent_password`) VALUES
(1, 'Gurdian Name', 'Father Name', 'Mother Name', 'Father\'s Profession', 'Mother\'s Profession', 'ram_parent@gmail.com', '1234567888', 'aaaaaaaaaaaa\r\nbbbbbbbbbb\r\nccccccccccccc\r\nddddddddddddddddd\r\n', 'gal1.jpg', 'parentuser', 'parentpass');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_q_bank`
--

CREATE TABLE `tbl_q_bank` (
  `qbank_id` int(11) NOT NULL,
  `q_group` varchar(50) NOT NULL,
  `question` text NOT NULL,
  `explanation` text NOT NULL,
  `upload` varchar(100) NOT NULL,
  `hints` varchar(50) NOT NULL,
  `mark` int(10) NOT NULL,
  `qtype` varchar(50) NOT NULL,
  `dummy` int(11) NOT NULL,
  `dummy2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_routine`
--

CREATE TABLE `tbl_routine` (
  `routine_id` int(11) NOT NULL,
  `routine_school_year` varchar(50) NOT NULL,
  `routine_class` varchar(50) NOT NULL,
  `routine_section` varchar(50) NOT NULL,
  `routine_subject` varchar(50) NOT NULL,
  `routine_day` varchar(40) NOT NULL,
  `routine_teacher` varchar(50) NOT NULL,
  `routine_start_time` varchar(20) NOT NULL,
  `routine_end_time` varchar(20) NOT NULL,
  `routine_room` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_section`
--

CREATE TABLE `tbl_section` (
  `section_id` int(11) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `section_category` varchar(50) NOT NULL,
  `section_capacity` varchar(50) NOT NULL,
  `section_class` varchar(50) NOT NULL,
  `section_teacher_name` varchar(50) NOT NULL,
  `section_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_section`
--

INSERT INTO `tbl_section` (`section_id`, `section_name`, `section_category`, `section_capacity`, `section_class`, `section_teacher_name`, `section_note`) VALUES
(1, 'Section Namewqwqwqwq', 'category nwqwqwame', '35wqw', 'Three', 'shyam Two', 'A quick brown fox jumps right ove the laxy dog.  A quick brown fox jumps right ove the laxy dog. A quick brown fox jumps right ove the laxy dog. A quick brown fox jumps right ove the laxy dog. A quick brown fox jumps right ove the laxy dog. A quick brown fox jumps right ove the laxy dog. A quick brown fox jumps right ove the laxy dog. A quick brown fox jumps right ove the laxy dog. A quick brown fox jumps right ove the laxy dog. '),
(2, 'Section Name', 'category nwqwqwame', '35', 'Two', 'shyam Two', 'a quicj briwn fox jumps '),
(3, 'sec1111', '2222', '23', 'One', 'Jadu Three', 'qwert');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_state`
--

CREATE TABLE `tbl_state` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(50) NOT NULL,
  `state_code` varchar(5) NOT NULL,
  `dummy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `student_gurdian` varchar(100) NOT NULL,
  `student_dob` varchar(50) NOT NULL,
  `student_gender` varchar(1) NOT NULL,
  `student_blood_group` varchar(5) NOT NULL,
  `student_relegion` varchar(20) NOT NULL,
  `student_email` varchar(100) NOT NULL,
  `student_phone` varchar(50) NOT NULL,
  `student_address` text NOT NULL,
  `student_state` varchar(20) NOT NULL,
  `student_country` varchar(20) NOT NULL,
  `student_city` varchar(20) NOT NULL,
  `student_class` varchar(10) NOT NULL,
  `student_section` varchar(5) NOT NULL,
  `student_group` varchar(25) NOT NULL,
  `student_opt_subject` varchar(20) NOT NULL,
  `student_register_no` varchar(25) NOT NULL,
  `student_roll_no` varchar(5) NOT NULL,
  `student_photo` varchar(100) NOT NULL,
  `student_extra_curr` varchar(25) NOT NULL,
  `student_remark` text NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `student_password` varchar(50) NOT NULL,
  `student_added_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `student_updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`student_id`, `student_name`, `student_gurdian`, `student_dob`, `student_gender`, `student_blood_group`, `student_relegion`, `student_email`, `student_phone`, `student_address`, `student_state`, `student_country`, `student_city`, `student_class`, `student_section`, `student_group`, `student_opt_subject`, `student_register_no`, `student_roll_no`, `student_photo`, `student_extra_curr`, `student_remark`, `student_username`, `student_password`, `student_added_time`, `student_updated_time`) VALUES
(1, 'Ram', 'Ram Gurdian', '', 'M', 'A+', 'Hindu', 'ram@gmail.com', '1234567899', 'Ram Address', 'Active', 'India', '', '5', 'A', 'Group1', 'Math', '1111111', '15', '', 'yoga', 'rem1', '', '', '2018-02-23 10:53:42', '2018-02-23 10:54:32'),
(2, 'Shyam', 'Shyam Gurdian', '', 'M', 'A-', 'Hindu', 'shyam@gmail.com', '2345678901', 'Shyam address', 'Active', 'India', '', '6', 'B', 'Group2', 'Math', '2222222', '16', '', 'painting', 'rem2', '', '', '2018-02-23 10:53:42', '2018-02-23 10:54:32'),
(3, 'Jadu', 'Jadu Gurdian', '', 'M', 'B+', 'Hindu', 'Jadu@gmail.com', '3456789012', 'Jadu Address', 'Active', 'India', '', '7', 'C', 'Group3', 'Math', '3333333', '17', '', 'singing', 'rem3', '', '', '2018-02-23 10:53:42', '2018-02-23 10:54:32'),
(4, 'Madhu', 'Madhu Gurdian', '', 'M', 'C+', 'Hindu', 'Madhu@gmail.com', '4567890123', 'Madhu address', 'Active', 'India', '', '8', 'D', 'Group4', 'Math', '4444444', '18', '', 'yoga', 'rem4', '', '', '2018-02-23 10:53:42', '2018-02-23 10:54:32'),
(5, 'Shivam Yadav', 'Suraj Yadav', '12-12-2017', 'M', 'A+', 'Hinduism', 'golu@gmail.com', '8100455586', 'Andul Road,\r\nchunabhati More,\r\nNear MAcher Bazar,\r\nHowrah - 711109', 'West Bengal', 'India', 'Kolkata', 'One', 'B', 'Science', 'Math', 'R76546544', '10', 'userpic.gif', 'Playing Cricket', 'There is not remark1.\r\nThere is not remark2.\r\nThere is not remark3.', 'apysan@gmail.com', 'bharatindia', '2018-02-23 10:53:42', '2018-02-23 10:54:32'),
(6, 'Tanya Das', 'Vinod Kumar', '05-10-2017', 'F', 'AB+', 'Hinduism', 'tanya@gmail.com', '6576876578', 'address1\r\naddress2\r\naddress3\r\naddress4', 'West Bengal', 'India', 'Kolkata', 'Three', 'Selec', 'Art', 'Bengali', 'R097089798798708', '10', 'img2.jpg', 'playing chess', 'no remark1111111111111\r\nno remark1111111111111\r\nno remark1111111111111\r\nno remar44444444444444444444444444444444444444444', 'tanya@rediffmail.com', '12345', '2018-02-23 10:57:54', '2018-02-23 10:57:54'),
(7, 'wqwq', 'wqwq', 'wqw', 'M', 'A-', 'Hinduism', 'wqwq', 'qwq', 'wqwq', 'wqw', 'wqwq', 'wqw', 'One', 'B', 'Commerce', 'Bengali', 'wqwqw', 'wqwq', 'img1.jpg', 'wqwq', 'wqwqwwqw', 'sitsolution', '12345', '2018-02-23 11:04:52', '2018-02-23 11:04:52'),
(8, 'wqwqwqwqwqw', 'wqwqw', 'wqw', 'M', 'B+', 'Hinduism', 'apysan@gmail.com', '8100455586', 'wqwqwqwqwqwqwqw', 'wqwqwq', 'wqwq', 'wqwqwq', 'Three', 'B', 'Commerce', 'Bengali', 'tiut87687q6w8769q6w78q6w8', '34', 'gal1.jpg', '323232323', 'wewewewe', 'apysan@gmail.com', 'bharat', '2018-02-23 11:06:11', '2018-02-23 11:06:11'),
(9, 'qqqqqqq', 'wqwq', '12/12/2018', 'M', 'B+', 'Islam', 'tanya@gmail.com', '8100455586', 'qqqqqqqqqq', 'West Bengal', 'India', 'Kolkata', 'Four', 'A', 'Science', 'Bengali', '876f87a6d98f7a6987678er69', '22', 'gal6.jpg', 'eeeeeeeeeeeeeeeeeeeee', 'rrrrrrrrrrrrrrrrrrrrrrrrrr', 'sitsolution', '12345', '2018-02-23 11:11:28', '2018-02-23 11:11:28'),
(10, 'qqqqqqq', 'wwwwwwwwwww', '12/12/2018', 'M', 'B+', 'Buddhism', 'tanya@gmail.com', '55555555555', 'ererererererererre', 'West Bengal', 'India', 'Kolkata', 'Seven', 'B', 'Art', 'Bengali', '876f87a6d98f7a6987678er69', '23', 'gal6.jpg', 'Yoga', 'reererererwerewrer', 'apysan@gmail.com', 'bharatindia', '2018-02-23 11:13:05', '2018-02-23 11:13:05'),
(11, 'qqqqqqqqqqq', '', '', 'S', 'Selec', 'Select Religion', '', '', '', '', '', '', 'Select Cla', 'Selec', 'Select Group', 'Select Opt Subject', '', '', '', '', '', 'sitsolution', '12345', '2018-02-23 11:21:43', '2018-02-23 11:21:43'),
(12, 'Shivam Yadav', '', '', 'S', 'Selec', 'Select Religion', '', '', '', '', '', '', 'Select Cla', 'Selec', 'Select Group', 'Select Opt Subject', '', '', '', '', '', 'sitsolution', '12345', '2018-02-23 11:22:58', '2018-02-23 11:22:58'),
(13, 'Shivam Yadav', '', '', 'S', 'Selec', 'Select Religion', '', '', '', '', '', '', 'Select Cla', 'Selec', 'Select Group', 'Select Opt Subject', '', '', '', '', '', 'sitsolution', '12345', '2018-02-23 11:24:29', '2018-02-23 11:24:29'),
(14, 'Shivam Yadav', '', '', 'S', 'Selec', 'Select Religion', '', '', '', '', '', '', 'Select Cla', 'Selec', 'Select Group', 'Select Opt Subject', '', '', '', '', '', 'sitsolution', '12345', '2018-02-23 11:25:21', '2018-02-23 11:25:21'),
(15, 'Tanya Das', 'Vinod Kumar', '02/23/2018', 'M', 'A-', 'Hinduism', 'apysan@gmail.com', '8100455586', 'ewewewe wewewe hhjhjkhkjhjkh jkhjhkjhkjh kjhjkhkjh kjhkjhjkh kjhkjhkjh \r\nhfg hghfhgfghfghfhgfghf fghfghfghfhf gfhgfghfhgfhgfghf ghfgfhgfghfghf ghfhgfghfgh\r\njhfdkshfjdhfjksdhfjsdhfjksdhf \r\nkhfdlhfjkdhfjkdhfjkdhafjkhdfjdhsjkfh', 'West Bengal', 'India', 'Kolkata', 'Four', 'B', 'Commerce', 'Bengali', 'R097089798798708', '45', 'gal3.jpg', 'extrrrrrrrrrrrrrrrrrrrrrr', 'rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr', 'sitsolution', '12345', '2018-02-23 11:41:39', '2018-02-23 11:41:39'),
(16, 'Shivam Yadav', 'Vinod Kumar', '02/23/2018', 'M', 'A+', 'Hinduism', 'apysan@gmail.com', '8100455586', 'qqqqqqqqqqqqqqqqq', 'West Bengal', 'India', 'Kolkata', 'Seven', 'B', 'Science', 'Bengali', 'R097089798798708', '34', 'img2.jpg', 'extrrrrrrrrrrrrrrrrrrrrrr', 'qqqqqqqqqq', 'sitsolution', '12345', '2018-02-23 12:04:27', '2018-02-23 12:04:27'),
(17, 'Shivam Yadav', 'Vinod Kumar', '12/12/2018', 'M', 'A+', 'Hinduism', 'apysan@shivam.com', '8100455586', 'address1\r\naddress2\r\naddress3\r\naddress4', 'West Bengal', 'India', 'Kolkata', 'Ten', 'B', 'Commerce', 'Math', 'R097089798798708', '24', 'gal4.jpg', 'yogo', 'remark', 'apysan@gmail.com', 'bharatindia', '2018-02-26 05:09:48', '2018-02-26 05:09:48'),
(18, 'Shivam Yadav', '', '', 'S', 'Selec', 'Select Religion', '', '', '', 'West Bengal', 'Select Country', 'Kolkata', 'Seven', 'A', 'Commerce', 'Select Opt Subject', '', '', 'favicon.ico', '', '', 'sitsolution', '12345', '2018-02-26 07:02:58', '2018-02-26 07:02:58'),
(19, 'qqqqqqqqqqq', '', '', 'S', 'Selec', 'Select Religion', '', '', '', '', '', '', 'Select Cla', 'Selec', 'Select Group', 'Select Opt Subject', '', '', 'image/student_image/avatar.png', '', '', 'sitsolution', '12345', '2018-02-27 05:22:40', '2018-02-27 05:22:40'),
(20, '11111111', '', '', 'S', 'Selec', 'Select Religion', '', '', '', 'Select State', 'Select Country', 'Select City', 'Select Cla', 'Selec', 'Select Group', 'Select Opt Subject', '', '', 'avatar.png', '', '', 'sitsolution', '12345', '2018-02-27 10:03:02', '2018-02-27 10:03:02'),
(21, 'Ramsharan gupta', '', '', 'S', 'Selec', 'Select Religion', '', '', '', '', '', '', 'Select Cla', 'Selec', 'Select Group', 'Select Opt Subject', '', '', 'image/student_image/avatar.png', '', '', 'sitsolution', '12345', '2018-02-27 10:23:18', '2018-02-27 10:23:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject`
--

CREATE TABLE `tbl_subject` (
  `subject_id` int(11) NOT NULL,
  `class_name` varchar(20) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `subject_type` varchar(50) NOT NULL,
  `pass_mark` int(11) NOT NULL,
  `final_mark` int(11) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `subject_author` varchar(50) NOT NULL,
  `subject_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_subject`
--

INSERT INTO `tbl_subject` (`subject_id`, `class_name`, `teacher_name`, `subject_type`, `pass_mark`, `final_mark`, `subject_name`, `subject_author`, `subject_code`) VALUES
(1, 'Five', 'Teacher1', 'Mandatory', 40, 100, 'Hindi', 'D K Saha', 'h1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_syllabus`
--

CREATE TABLE `tbl_syllabus` (
  `syllabus_id` int(11) NOT NULL,
  `syllabus_title` varchar(100) NOT NULL,
  `syllabus_description` text NOT NULL,
  `syllabus_class` varchar(20) NOT NULL,
  `syllabus_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_syllabus`
--

INSERT INTO `tbl_syllabus` (`syllabus_id`, `syllabus_title`, `syllabus_description`, `syllabus_class`, `syllabus_file`) VALUES
(1, 'The syllabus Title', 'qqqqqqqqq', 'One', 'lo');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher`
--

CREATE TABLE `tbl_teacher` (
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(100) NOT NULL,
  `teacher_designation` varchar(100) NOT NULL,
  `teacher_DOB` varchar(50) NOT NULL,
  `teacher_gender` varchar(1) NOT NULL,
  `teacher_religion` varchar(50) NOT NULL,
  `teacher_email` varchar(100) NOT NULL,
  `teacher_phone` varchar(100) NOT NULL,
  `teacher_address` varchar(100) NOT NULL,
  `teacher_DOJ` varchar(50) NOT NULL,
  `teacher_photo` varchar(100) NOT NULL,
  `teacher_username` varchar(50) NOT NULL,
  `teacher_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_teacher`
--

INSERT INTO `tbl_teacher` (`teacher_id`, `teacher_name`, `teacher_designation`, `teacher_DOB`, `teacher_gender`, `teacher_religion`, `teacher_email`, `teacher_phone`, `teacher_address`, `teacher_DOJ`, `teacher_photo`, `teacher_username`, `teacher_password`) VALUES
(1, 'name of teacher', 'designation of teacher', '12/12/2018', 'M', 'Hinduism', 'teacher@gmail.com', '1234567899, 5656543578, 7654345678', 'qqqqqqqqqqqq\r\nwwwwwwwwwwwwww\r\neeeeeeeeeeeeeeeee\r\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr', '12/12/2018', 'favicon.ico', 'teacheruser', 'tpass'),
(2, 'Second Teacher', 'Second teacher Designation', '11/11/2018', 'F', 'Buddhism', 'teacher@rediffmail.com', '1234567899, 5656543578, 7654345678, 7777777777', 'address1\r\naddress2\r\naddress3\r\naddresss4', '12/12/2017', 'gal1.jpg', 'teacher2user', 'teacher2pass');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transport`
--

CREATE TABLE `tbl_transport` (
  `transport_id` int(11) NOT NULL,
  `transport_route_name` varchar(50) NOT NULL,
  `transport_no_of_vehicle` int(11) NOT NULL,
  `transport_fare` decimal(10,2) NOT NULL,
  `transport_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trans_memb`
--

CREATE TABLE `tbl_trans_memb` (
  `trans_memb_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `roll` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_role` tinyint(1) NOT NULL,
  `user_DOB` varchar(50) NOT NULL,
  `user_gender` varchar(1) NOT NULL,
  `user_religion` varchar(50) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_phone` varchar(100) NOT NULL,
  `user_address` varchar(100) NOT NULL,
  `user_DOJ` varchar(50) NOT NULL,
  `user_photo` varchar(100) NOT NULL,
  `user_username` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_role`, `user_DOB`, `user_gender`, `user_religion`, `user_email`, `user_phone`, `user_address`, `user_DOJ`, `user_photo`, `user_username`, `user_password`) VALUES
(1, 'User_name', 0, '12/12/2017', 'M', 'Hinduism', 'apysan@zoto.com', '1234567899, 5565656565, 6666666666', 'qqqqqqqqqqq\r\nwwwwwwwwwwwww\r\neeeeeeeeeee\r\nrrrrrrrrrrrrrrrrrrrr', '12/12/1990', 'favicon.ico', 'uuuuuuuuuuuuuuuuuu', 'ppppppppppppppppppppp'),
(2, 'librarian', 6, '12/12/2017', 'M', 'Islam', 'apysan@zoto.com', '1234567899, 5565656565, 6666666666', 'qqqqqqqqqqqqqqqq', '', '', 'uuuuuuuuuuu', 'ppppppppp');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_visitor`
--

CREATE TABLE `tbl_visitor` (
  `visitor_id` int(11) NOT NULL,
  `visitor_name` varchar(100) NOT NULL,
  `visitor_email` varchar(20) NOT NULL,
  `visitor_phone` varchar(50) NOT NULL,
  `visitor_company` varchar(100) NOT NULL,
  `visitor_comingfrom` varchar(50) NOT NULL,
  `visitor_tomeet` varchar(50) NOT NULL,
  `visitor_tomeet_usertype` varchar(50) NOT NULL,
  `visitor_checkin` varchar(20) NOT NULL,
  `visitor_checkout` varchar(20) NOT NULL,
  `visitor_status` varchar(20) NOT NULL,
  `visitor_action` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_assignment`
--
ALTER TABLE `tbl_assignment`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `tbl_city`
--
ALTER TABLE `tbl_city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `tbl_class`
--
ALTER TABLE `tbl_class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `tbl_exam`
--
ALTER TABLE `tbl_exam`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `tbl_exam_grade`
--
ALTER TABLE `tbl_exam_grade`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `tbl_exam_schedule`
--
ALTER TABLE `tbl_exam_schedule`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `tbl_gurdian`
--
ALTER TABLE `tbl_gurdian`
  ADD PRIMARY KEY (`Gurdian_id`);

--
-- Indexes for table `tbl_hostel`
--
ALTER TABLE `tbl_hostel`
  ADD PRIMARY KEY (`hostel_id`);

--
-- Indexes for table `tbl_hostel_cat`
--
ALTER TABLE `tbl_hostel_cat`
  ADD PRIMARY KEY (`hostel_id`);

--
-- Indexes for table `tbl_library_book`
--
ALTER TABLE `tbl_library_book`
  ADD PRIMARY KEY (`lib_book_id`);

--
-- Indexes for table `tbl_library_memb`
--
ALTER TABLE `tbl_library_memb`
  ADD PRIMARY KEY (`lib_mem_id`);

--
-- Indexes for table `tbl_mail_sms`
--
ALTER TABLE `tbl_mail_sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_parent`
--
ALTER TABLE `tbl_parent`
  ADD PRIMARY KEY (`parent_id`);

--
-- Indexes for table `tbl_q_bank`
--
ALTER TABLE `tbl_q_bank`
  ADD PRIMARY KEY (`qbank_id`);

--
-- Indexes for table `tbl_routine`
--
ALTER TABLE `tbl_routine`
  ADD PRIMARY KEY (`routine_id`);

--
-- Indexes for table `tbl_section`
--
ALTER TABLE `tbl_section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `tbl_state`
--
ALTER TABLE `tbl_state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `tbl_syllabus`
--
ALTER TABLE `tbl_syllabus`
  ADD PRIMARY KEY (`syllabus_id`);

--
-- Indexes for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `tbl_transport`
--
ALTER TABLE `tbl_transport`
  ADD PRIMARY KEY (`transport_id`);

--
-- Indexes for table `tbl_trans_memb`
--
ALTER TABLE `tbl_trans_memb`
  ADD PRIMARY KEY (`trans_memb_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_visitor`
--
ALTER TABLE `tbl_visitor`
  ADD PRIMARY KEY (`visitor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_assignment`
--
ALTER TABLE `tbl_assignment`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_city`
--
ALTER TABLE `tbl_city`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_class`
--
ALTER TABLE `tbl_class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_exam`
--
ALTER TABLE `tbl_exam`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_exam_grade`
--
ALTER TABLE `tbl_exam_grade`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_exam_schedule`
--
ALTER TABLE `tbl_exam_schedule`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_gurdian`
--
ALTER TABLE `tbl_gurdian`
  MODIFY `Gurdian_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_hostel`
--
ALTER TABLE `tbl_hostel`
  MODIFY `hostel_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_hostel_cat`
--
ALTER TABLE `tbl_hostel_cat`
  MODIFY `hostel_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_library_book`
--
ALTER TABLE `tbl_library_book`
  MODIFY `lib_book_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_library_memb`
--
ALTER TABLE `tbl_library_memb`
  MODIFY `lib_mem_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_mail_sms`
--
ALTER TABLE `tbl_mail_sms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_parent`
--
ALTER TABLE `tbl_parent`
  MODIFY `parent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_q_bank`
--
ALTER TABLE `tbl_q_bank`
  MODIFY `qbank_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_routine`
--
ALTER TABLE `tbl_routine`
  MODIFY `routine_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_section`
--
ALTER TABLE `tbl_section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_state`
--
ALTER TABLE `tbl_state`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_syllabus`
--
ALTER TABLE `tbl_syllabus`
  MODIFY `syllabus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_transport`
--
ALTER TABLE `tbl_transport`
  MODIFY `transport_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_trans_memb`
--
ALTER TABLE `tbl_trans_memb`
  MODIFY `trans_memb_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_visitor`
--
ALTER TABLE `tbl_visitor`
  MODIFY `visitor_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
